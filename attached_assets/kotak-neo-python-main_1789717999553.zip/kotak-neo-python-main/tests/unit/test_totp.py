"""Unit tests for TOTP authentication service."""

from neo_api_client import NeoAPI
from neo_api_client.services.totp import TotpAPI


def test_totp_login_uses_uat_path_on_uat(requests_mock):
    """Regression: totp_login() must hit the UAT-specific endpoint path on
    uat, not silently send the PROD path (a completely different shape --
    "login/1.0/tradeApiLogin" vs "api/1.0/login/v6/totp/login")."""
    client = NeoAPI(environment="uat", consumer_key="test_key")
    uat_login_url = "https://d-mis.kotaksecurities.com/api/1.0/login/v6/totp/login"

    requests_mock.post(
        uat_login_url,
        json={"data": {"token": "view_token_123", "sid": "view_sid_456"}},
        status_code=200,
    )

    result = client.totp_login(mobile_number="+919999999999", ucc="TESTUSER", totp="123456")

    assert result["data"]["token"] == "view_token_123"
    assert requests_mock.last_request.url == uat_login_url


def test_totp_validate_uses_uat_path_on_uat(requests_mock):
    """Same regression, for totp_validate()."""
    client = NeoAPI(environment="uat", consumer_key="test_key")
    client.configuration.view_token = "view_token_123"
    client.configuration.sid = "view_sid_456"
    uat_validate_url = "https://d-mis.kotaksecurities.com/api/1.0/login/v6/totp/validate"

    requests_mock.post(
        uat_validate_url,
        json={"data": {"token": "edit_token_123", "sid": "edit_sid_456"}},
        status_code=200,
    )

    result = client.totp_validate(mpin="654321")

    assert result["data"]["token"] == "edit_token_123"
    assert requests_mock.last_request.url == uat_validate_url


def test_totp_api_init(api_client):
    """Test TotpAPI initialization."""
    totp_api = TotpAPI(api_client)
    assert totp_api.api_client == api_client
    assert totp_api.rest_client == api_client.rest_client
    assert totp_api.totp_session is None


def test_totp_login_success(api_client, requests_mock):
    """Test successful TOTP login."""
    login_url = api_client.configuration.get_domain(session_init=True) + "/login/1.0/tradeApiLogin"

    requests_mock.post(
        login_url,
        json={
            "data": {
                "token": "view_token_123",
                "sid": "view_sid_456",
                "rid": "view_rid_789",
            }
        },
        status_code=200,
    )

    totp_api = TotpAPI(api_client)
    result = totp_api.totp_login(
        mobile_number="+919999999999",
        ucc="TESTUSER",
        totp="123456",
    )

    assert result["data"]["token"] == "view_token_123"
    assert result["data"]["sid"] == "view_sid_456"
    assert api_client.configuration.view_token == "view_token_123"
    assert api_client.configuration.sid == "view_sid_456"


def test_totp_validate_success(api_client, requests_mock):
    """Test successful TOTP validation."""
    # First login to set view_token and sid
    api_client.configuration.view_token = "view_token_123"
    api_client.configuration.sid = "view_sid_456"

    validate_url = (
        api_client.configuration.get_domain(session_init=True) + "/login/1.0/tradeApiValidate"
    )

    requests_mock.post(
        validate_url,
        json={
            "data": {
                "token": "edit_token_123",
                "sid": "edit_sid_456",
                "rid": "edit_rid_789",
                "dataCenter": "DC1",
                "baseUrl": "https://test.com",
            }
        },
        status_code=200,
    )

    totp_api = TotpAPI(api_client)
    result = totp_api.totp_validate(mpin="654321")

    assert result["data"]["token"] == "edit_token_123"
    assert result["data"]["sid"] == "edit_sid_456"
    assert api_client.configuration.edit_token == "edit_token_123"
    assert api_client.configuration.edit_sid == "edit_sid_456"
    assert api_client.configuration.data_center == "DC1"


def test_totp_login_with_none_values(api_client, requests_mock):
    """Test TOTP login accepts None values without raising errors."""
    login_url = api_client.configuration.get_domain(session_init=True) + "/login/1.0/tradeApiLogin"

    requests_mock.post(
        login_url,
        json={"data": {"token": "test", "sid": "test"}},
        status_code=200,
    )

    totp_api = TotpAPI(api_client)
    # Should not raise TypeError
    result = totp_api.totp_login(mobile_number=None, ucc=None, totp=None)

    assert "data" in result


def test_totp_validate_with_none_mpin(api_client, requests_mock):
    """Test TOTP validate accepts None mpin without raising errors."""
    api_client.configuration.view_token = "view_token"
    api_client.configuration.sid = "sid"

    validate_url = (
        api_client.configuration.get_domain(session_init=True) + "/login/1.0/tradeApiValidate"
    )

    requests_mock.post(
        validate_url,
        json={"data": {"token": "edit_token", "sid": "edit_sid", "rid": "rid"}},
        status_code=200,
    )

    totp_api = TotpAPI(api_client)
    # Should not raise TypeError
    result = totp_api.totp_validate(mpin=None)

    assert "data" in result


def test_totp_login_invalid_json_response(api_client, requests_mock):
    """Test TOTP login with invalid JSON response."""
    login_url = api_client.configuration.get_domain(session_init=True) + "/login/1.0/tradeApiLogin"

    requests_mock.post(login_url, text="Invalid JSON", status_code=200)

    totp_api = TotpAPI(api_client)
    result = totp_api.totp_login(
        mobile_number="+919999999999",
        ucc="TESTUSER",
        totp="123456",
    )

    assert "Error" in result
    assert "Unexpected response format" in result["Error"]


def test_totp_validate_invalid_json_response(api_client, requests_mock):
    """Test TOTP validate with invalid JSON response."""
    api_client.configuration.view_token = "view_token"
    api_client.configuration.sid = "sid"

    validate_url = (
        api_client.configuration.get_domain(session_init=True) + "/login/1.0/tradeApiValidate"
    )

    requests_mock.post(validate_url, text="Invalid JSON", status_code=200)

    totp_api = TotpAPI(api_client)
    result = totp_api.totp_validate(mpin="123456")

    assert "Error" in result
    assert "Unexpected response format" in result["Error"]


def test_totp_login_error_status(api_client, requests_mock):
    """Test TOTP login with error status code."""
    login_url = api_client.configuration.get_domain(session_init=True) + "/login/1.0/tradeApiLogin"

    requests_mock.post(
        login_url,
        json={"stat": "Not_Ok", "message": "Invalid credentials"},
        status_code=401,
    )

    totp_api = TotpAPI(api_client)
    result = totp_api.totp_login(
        mobile_number="+919999999999",
        ucc="TESTUSER",
        totp="000000",
    )

    assert result["stat"] == "Not_Ok"
    # Configuration should not be updated on error
    assert api_client.configuration.view_token is None


def test_totp_login_2xx_error_body_no_data(api_client, requests_mock):
    """A 2xx response with an error body (no 'data') must not raise.

    Regression: an empty/invalid UCC returns HTTP 200 with an error payload and
    no 'data' key; the SDK must return that payload rather than raising
    AttributeError.
    """
    login_url = api_client.configuration.get_domain(session_init=True) + "/login/1.0/tradeApiLogin"

    requests_mock.post(
        login_url,
        json={"stCode": 429, "errMsg": "Invalid UCC", "status": "failure"},
        status_code=200,
    )

    totp_api = TotpAPI(api_client)
    result = totp_api.totp_login(mobile_number="+919999999999", ucc="", totp="123456")

    assert result["errMsg"] == "Invalid UCC"
    assert result["status"] == "failure"
    # No token extracted from an error body.
    assert api_client.configuration.view_token is None


def test_totp_validate_2xx_error_body_no_data(api_client, requests_mock):
    """totp_validate with a 2xx error body (no 'data') must not raise."""
    validate_url = (
        api_client.configuration.get_domain(session_init=True) + "/login/1.0/tradeApiValidate"
    )

    requests_mock.post(
        validate_url,
        json={"stCode": 401, "errMsg": "Invalid MPIN", "status": "failure"},
        status_code=200,
    )

    # Clear any pre-set token so we can assert it is not populated on error.
    api_client.configuration.edit_token = None

    totp_api = TotpAPI(api_client)
    result = totp_api.totp_validate(mpin="0000")

    assert result["errMsg"] == "Invalid MPIN"
    assert api_client.configuration.edit_token is None
