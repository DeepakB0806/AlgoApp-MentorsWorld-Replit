import { supabase } from "@/integrations/supabase/client";

export const settingsService = {
  async ensureProfileExists(): Promise<void> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error("User not authenticated");

    // Check if profile exists
    const { data: existingProfile } = await supabase
      .from("profiles")
      .select("id")
      .eq("id", user.id)
      .maybeSingle();

    // If profile doesn't exist, create it
    if (!existingProfile) {
      const { error } = await supabase
        .from("profiles")
        .insert({
          id: user.id,
          email: user.email,
          full_name: user.user_metadata?.full_name || user.user_metadata?.name,
          avatar_url: user.user_metadata?.avatar_url || user.user_metadata?.picture,
        });

      if (error) throw error;
    }
  },

  async getDomainName(): Promise<string | null> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;

    const { data, error } = await supabase
      .from("app_settings")
      .select("value")
      .eq("user_id", user.id)
      .eq("key", "domain_name")
      .maybeSingle();

    if (error) {
      console.error("Error fetching domain name:", error);
      return null;
    }

    return data?.value || null;
  },

  async saveDomainName(domain: string): Promise<void> {
    // Ensure profile exists before saving settings
    await this.ensureProfileExists();

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error("User not authenticated");

    // Check if domain setting already exists
    const { data: existing } = await supabase
      .from("app_settings")
      .select("id")
      .eq("user_id", user.id)
      .eq("key", "domain_name")
      .maybeSingle();

    if (existing) {
      // Update existing domain
      const { error } = await supabase
        .from("app_settings")
        .update({ value: domain })
        .eq("id", existing.id);

      if (error) {
        console.error("Error updating domain name:", error);
        throw error;
      }
    } else {
      // Insert new domain setting
      const { error } = await supabase
        .from("app_settings")
        .insert({
          user_id: user.id,
          key: "domain_name",
          value: domain,
        });

      if (error) {
        console.error("Error saving domain name:", error);
        throw error;
      }
    }
  },

  async saveWebhook(webhookId: string, webhookName: string, color: string = "#3b82f6"): Promise<boolean> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return false;

    const webhookData = JSON.stringify({
      name: webhookName,
      color: color,
    });

    const { error } = await supabase
      .from("app_settings")
      .insert({
        user_id: user.id,
        key: `webhook_${webhookId}`,
        value: webhookData,
      });

    if (error) {
      console.error("Error saving webhook:", error);
      return false;
    }

    return true;
  },

  async getWebhooks(): Promise<Array<{ id: string; name: string; color: string; createdAt: string }>> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return [];

    const { data, error } = await supabase
      .from("app_settings")
      .select("key, value, created_at")
      .eq("user_id", user.id)
      .like("key", "webhook_%")
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Error fetching webhooks:", error);
      return [];
    }

    return (data || []).map((item) => {
      let webhookData;
      try {
        webhookData = JSON.parse(item.value);
      } catch {
        // Fallback for old format (plain string)
        webhookData = { name: item.value, color: "#3b82f6" };
      }

      return {
        id: item.key.replace("webhook_", ""),
        name: webhookData.name || item.value,
        color: webhookData.color || "#3b82f6",
        createdAt: item.created_at,
      };
    });
  },

  async deleteWebhook(webhookId: string): Promise<boolean> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return false;

    const { error } = await supabase
      .from("app_settings")
      .delete()
      .eq("user_id", user.id)
      .eq("key", `webhook_${webhookId}`);

    if (error) {
      console.error("Error deleting webhook:", error);
      return false;
    }

    return true;
  },

  async updateWebhookName(webhookId: string, newName: string): Promise<boolean> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return false;

    // Get existing webhook data to preserve color
    const { data: existing } = await supabase
      .from("app_settings")
      .select("value")
      .eq("user_id", user.id)
      .eq("key", `webhook_${webhookId}`)
      .maybeSingle();

    let color = "#3b82f6";
    if (existing) {
      try {
        const webhookData = JSON.parse(existing.value);
        color = webhookData.color || "#3b82f6";
      } catch {
        // Old format, use default color
      }
    }

    const updatedData = JSON.stringify({
      name: newName,
      color: color,
    });

    const { error } = await supabase
      .from("app_settings")
      .update({ value: updatedData })
      .eq("user_id", user.id)
      .eq("key", `webhook_${webhookId}`);

    if (error) {
      console.error("Error updating webhook name:", error);
      return false;
    }

    return true;
  },

  async updateWebhookColor(webhookId: string, newColor: string): Promise<boolean> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return false;

    // Get existing webhook data to preserve name
    const { data: existing } = await supabase
      .from("app_settings")
      .select("value")
      .eq("user_id", user.id)
      .eq("key", `webhook_${webhookId}`)
      .maybeSingle();

    let name = "Unnamed Webhook";
    if (existing) {
      try {
        const webhookData = JSON.parse(existing.value);
        name = webhookData.name || existing.value;
      } catch {
        // Old format
        name = existing.value;
      }
    }

    const updatedData = JSON.stringify({
      name: name,
      color: newColor,
    });

    const { error } = await supabase
      .from("app_settings")
      .update({ value: updatedData })
      .eq("user_id", user.id)
      .eq("key", `webhook_${webhookId}`);

    if (error) {
      console.error("Error updating webhook color:", error);
      return false;
    }

    return true;
  },

  async generateWebhookId(): Promise<string> {
    return crypto.randomUUID();
  },
};