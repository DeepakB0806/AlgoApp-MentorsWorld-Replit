import axios from "axios";

const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:8000";

// Use ReturnType to get the instance type safely
type AxiosInstance = ReturnType<typeof axios.create>;

export interface LoginCredentials {
  consumer_key: string;
  consumer_secret: string;
  mobile_number: string;
  password: string;
  mpin: string;
  totp_secret?: string;
}

export interface OrderParams {
  exchange_segment: string;
  product: string;
  price: string;
  order_type: string;
  quantity: string;
  validity: string;
  trading_symbol: string;
  transaction_type: string;
  amo?: string;
  disclosed_quantity?: string;
  market_protection?: string;
  pf?: string;
  trigger_price?: string;
  tag?: string;
}

export interface ModifyOrderParams {
  order_id: string;
  price?: string;
  quantity?: string;
  trigger_price?: string;
  validity?: string;
  order_type?: string;
}

export interface QuoteParams {
  instrument_tokens: string[];
  quote_type?: string;
}

export interface Position {
  trading_symbol: string;
  exchange: string;
  product: string;
  quantity: number;
  buy_avg: number;
  sell_avg: number;
  pnl: number;
}

export interface Order {
  order_id: string;
  trading_symbol: string;
  exchange: string;
  transaction_type: string;
  order_type: string;
  quantity: number;
  price: number;
  status: string;
  filled_quantity: number;
  pending_quantity: number;
}

export interface Holding {
  trading_symbol: string;
  quantity: number;
  average_price: number;
  current_price: number;
  pnl: number;
}

class TradingService {
  private api: AxiosInstance;
  private sessionId: string | null = null;

  constructor() {
    this.api = axios.create({
      baseURL: BACKEND_URL,
      headers: {
        "Content-Type": "application/json",
      },
    });

    if (typeof window !== "undefined") {
      this.sessionId = localStorage.getItem("trading_session_id");
    }
  }

  async login(credentials: LoginCredentials): Promise<{ success: boolean; session_id: string; data: any }> {
    try {
      const response = await this.api.post("/api/auth/login", credentials);
      const data = response.data as any;
      
      if (data.success) {
        this.sessionId = data.session_id;
        if (typeof window !== "undefined") {
          localStorage.setItem("trading_session_id", this.sessionId!);
          localStorage.setItem("trading_session_data", JSON.stringify(data.data));
        }
      }
      
      return data;
    } catch (error: any) {
      throw new Error(error.response?.data?.detail || "Login failed");
    }
  }

  async logout(): Promise<void> {
    if (!this.sessionId) {
      throw new Error("No active session");
    }

    try {
      await this.api.delete(`/api/auth/logout?session_id=${this.sessionId}`);
      
      this.sessionId = null;
      if (typeof window !== "undefined") {
        localStorage.removeItem("trading_session_id");
        localStorage.removeItem("trading_session_data");
      }
    } catch (error: any) {
      throw new Error(error.response?.data?.detail || "Logout failed");
    }
  }

  async placeOrder(order: OrderParams): Promise<any> {
    if (!this.sessionId) {
      throw new Error("No active session. Please login first.");
    }

    try {
      const response = await this.api.post(
        `/api/orders/place?session_id=${this.sessionId}`,
        order
      );
      return response.data;
    } catch (error: any) {
      throw new Error(error.response?.data?.detail || "Order placement failed");
    }
  }

  async modifyOrder(params: ModifyOrderParams): Promise<any> {
    if (!this.sessionId) {
      throw new Error("No active session. Please login first.");
    }

    try {
      const response = await this.api.post(
        `/api/orders/modify?session_id=${this.sessionId}`,
        params
      );
      return response.data;
    } catch (error: any) {
      throw new Error(error.response?.data?.detail || "Order modification failed");
    }
  }

  async cancelOrder(orderId: string): Promise<any> {
    if (!this.sessionId) {
      throw new Error("No active session. Please login first.");
    }

    try {
      const response = await this.api.delete(
        `/api/orders/cancel/${orderId}?session_id=${this.sessionId}`
      );
      return response.data;
    } catch (error: any) {
      throw new Error(error.response?.data?.detail || "Order cancellation failed");
    }
  }

  async getOrders(): Promise<Order[]> {
    if (!this.sessionId) {
      throw new Error("No active session. Please login first.");
    }

    try {
      const response = await this.api.get(
        `/api/orders?session_id=${this.sessionId}`
      );
      return (response.data as any).data;
    } catch (error: any) {
      throw new Error(error.response?.data?.detail || "Failed to fetch orders");
    }
  }

  async getPositions(): Promise<Position[]> {
    if (!this.sessionId) {
      throw new Error("No active session. Please login first.");
    }

    try {
      const response = await this.api.get(
        `/api/positions?session_id=${this.sessionId}`
      );
      return (response.data as any).data;
    } catch (error: any) {
      throw new Error(error.response?.data?.detail || "Failed to fetch positions");
    }
  }

  async getHoldings(): Promise<Holding[]> {
    if (!this.sessionId) {
      throw new Error("No active session. Please login first.");
    }

    try {
      const response = await this.api.get(
        `/api/holdings?session_id=${this.sessionId}`
      );
      return (response.data as any).data;
    } catch (error: any) {
      throw new Error(error.response?.data?.detail || "Failed to fetch holdings");
    }
  }

  async getQuotes(params: QuoteParams): Promise<any> {
    if (!this.sessionId) {
      throw new Error("No active session. Please login first.");
    }

    try {
      const response = await this.api.post(
        `/api/quotes?session_id=${this.sessionId}`,
        params
      );
      return (response.data as any).data;
    } catch (error: any) {
      throw new Error(error.response?.data?.detail || "Failed to fetch quotes");
    }
  }

  async getMargins(): Promise<any> {
    if (!this.sessionId) {
      throw new Error("No active session. Please login first.");
    }

    try {
      const response = await this.api.get(
        `/api/margins?session_id=${this.sessionId}`
      );
      return (response.data as any).data;
    } catch (error: any) {
      throw new Error(error.response?.data?.detail || "Failed to fetch margins");
    }
  }

  async searchScrips(query: string, exchange: string = "NSE"): Promise<any> {
    if (!this.sessionId) {
      throw new Error("No active session. Please login first.");
    }

    try {
      const response = await this.api.get(
        `/api/scrips/search?query=${query}&exchange=${exchange}&session_id=${this.sessionId}`
      );
      return (response.data as any).data;
    } catch (error: any) {
      throw new Error(error.response?.data?.detail || "Search failed");
    }
  }

  connectWebSocket(onMessage: (data: any) => void): WebSocket | null {
    if (!this.sessionId) {
      console.error("No active session for WebSocket");
      return null;
    }

    const wsUrl = BACKEND_URL.replace("http", "ws");
    const ws = new WebSocket(`${wsUrl}/ws/market-data/${this.sessionId}`);

    ws.onopen = () => {
      console.log("WebSocket connected");
    };

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      onMessage(data);
    };

    ws.onerror = (error) => {
      console.error("WebSocket error:", error);
    };

    ws.onclose = () => {
      console.log("WebSocket disconnected");
    };

    return ws;
  }

  subscribeToInstruments(ws: WebSocket, instruments: string[]): void {
    ws.send(JSON.stringify({
      type: "subscribe",
      instruments: instruments
    }));
  }

  isAuthenticated(): boolean {
    return this.sessionId !== null;
  }

  getSessionId(): string | null {
    return this.sessionId;
  }
}

export const tradingService = new TradingService();