import { supabase } from "@/integrations/supabase/client";

export interface WebhookLog {
  id: string;
  user_id: string;
  time_unix: number | null;
  exchange: string | null;
  indices: string | null;
  indicator: string | null;
  alert: string | null;
  price: number | null;
  local_time: string | null;
  mode: string | null;
  mode_desc: string | null;
  first_line: number | null;
  mid_line: number | null;
  slow_line: number | null;
  st: number | null;
  ht: number | null;
  rsi: number | null;
  rsi_scaled: number | null;
  alert_system: string | null;
  action_binary: number | null;
  lock_state: string | null;
  created_at: string;
}

export const webhookLogService = {
  async getWebhookLogs(indicatorName: string): Promise<WebhookLog[]> {
    const tableName = `webhook_${indicatorName
      .toLowerCase()
      .replace(/[^a-z0-9]/g, "_")
      .replace(/_+/g, "_")
      .replace(/^_|_$/g, "")}`;

    try {
      const { data, error } = await supabase
        .from(tableName as any)
        .select("*")
        .order("created_at", { ascending: false })
        .limit(100);

      if (error) {
        console.error("Error fetching webhook logs:", error);
        throw new Error(`Failed to fetch logs: ${error.message}`);
      }

      return (data || []) as unknown as WebhookLog[];
    } catch (error: any) {
      console.error("Error in getWebhookLogs:", error);
      throw error;
    }
  },

  async insertWebhookLog(
    indicatorName: string,
    userId: string,
    logData: Partial<WebhookLog>
  ): Promise<WebhookLog> {
    const tableName = `webhook_${indicatorName
      .toLowerCase()
      .replace(/[^a-z0-9]/g, "_")
      .replace(/_+/g, "_")
      .replace(/^_|_$/g, "")}`;

    try {
      const { data, error } = await supabase
        .from(tableName as any)
        .insert([
          {
            user_id: userId,
            ...logData,
          },
        ])
        .select()
        .single();

      if (error) {
        console.error("Error inserting webhook log:", error);
        throw new Error(`Failed to insert log: ${error.message}`);
      }

      return data as unknown as WebhookLog;
    } catch (error: any) {
      console.error("Error in insertWebhookLog:", error);
      throw error;
    }
  },

  async deleteWebhookLogs(indicatorName: string, userId: string): Promise<void> {
    const tableName = `webhook_${indicatorName
      .toLowerCase()
      .replace(/[^a-z0-9]/g, "_")
      .replace(/_+/g, "_")
      .replace(/^_|_$/g, "")}`;

    try {
      const { error } = await supabase
        .from(tableName as any)
        .delete()
        .eq("user_id", userId);

      if (error) {
        console.error("Error deleting webhook logs:", error);
        throw new Error(`Failed to delete logs: ${error.message}`);
      }
    } catch (error: any) {
      console.error("Error in deleteWebhookLogs:", error);
      throw error;
    }
  },

  // TEMPORARILY DISABLED DUE TO TYPESCRIPT TYPE INFERENCE ISSUE
  // This function is not currently used in the UI
  /*
  async getLogStats(indicatorName: string): Promise<{
    total: number;
    buySignals: number;
    sellSignals: number;
    avgPrice: number;
  }> {
    const tableName = `webhook_${indicatorName
      .toLowerCase()
      .replace(/[^a-z0-9]/g, "_")
      .replace(/_+/g, "_")
      .replace(/^_|_$/g, "")}`;

    try {
      const baseQuery: any = supabase.from(tableName as any);
      const selectQuery: any = baseQuery.select("action_binary, price");
      const result: any = await selectQuery;
      
      if (result.error) {
        throw new Error(`Failed to fetch stats: ${result.error.message}`);
      }

      const logsArray: any[] = result.data || [];
      const buySignals = logsArray.filter((log: any) => log.action_binary === 1).length;
      const sellSignals = logsArray.filter((log: any) => log.action_binary === 0).length;
      const prices = logsArray.map((log: any) => log.price).filter((p: any) => p !== null);
      const avgPrice = prices.length > 0 
        ? prices.reduce((sum: number, p: number) => sum + p, 0) / prices.length 
        : 0;

      return {
        total: logsArray.length,
        buySignals,
        sellSignals,
        avgPrice,
      };
    } catch (error: any) {
      console.error("Error in getLogStats:", error);
      throw error;
    }
  },
  */

  async getLogsByWebhookId(webhookId: string) {
    // @ts-expect-error - Bypass deep type instantiation with Supabase query builder
    const { data, error } = await supabase
      .from("webhook_sun_7_99_14_btc")
      .select("*")
      .eq("webhook_id", webhookId)
      .order("created_at", { ascending: false });
      
    if (error) throw error;
    return data || [];
  },

  async testWebhook(webhookUrl: string): Promise<{
    success: boolean;
    status?: number;
    message: string;
    testData?: any;
  }> {
    try {
      const response = await fetch("/api/test-webhook", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ webhookUrl }),
      });

      const result = await response.json();
      return result;
    } catch (error) {
      console.error("Test webhook error:", error);
      return {
        success: false,
        message: "Failed to test webhook",
      };
    }
  },

  async saveTestLog(
    userId: string,
    webhookId: string,
    testPayload: any,
    status: string,
    statusCode: number,
    responseMessage: string,
    errorMessage?: string
  ): Promise<void> {
    try {
      const { error } = await supabase
        .from("indicator_webhook_test_log")
        .insert([
          {
            user_id: userId,
            webhook_id: webhookId,
            test_payload: testPayload,
            status: status,
            status_code: statusCode,
            response_message: responseMessage,
            error_message: errorMessage,
            tested_at: new Date().toISOString(),
          },
        ]);

      if (error) {
        console.error("Error saving test log:", error);
        throw new Error(`Failed to save test log: ${error.message}`);
      }
    } catch (error: any) {
      console.error("Error in saveTestLog:", error);
      throw error;
    }
  },

  async getTestLogs(webhookId: string): Promise<any[]> {
    try {
      const { data, error } = await supabase
        .from("indicator_webhook_test_log")
        .select("*")
        .eq("webhook_id", webhookId)
        .order("tested_at", { ascending: false })
        .limit(50);

      if (error) {
        console.error("Error fetching test logs:", error);
        throw new Error(`Failed to fetch test logs: ${error.message}`);
      }

      console.log(`Fetched ${data?.length || 0} test logs for webhook ${webhookId}`);
      return data || [];
    } catch (error: any) {
      console.error("Error in getTestLogs:", error);
      throw error;
    }
  },

  async getWebhookExecutionLogs(webhookId: string): Promise<any[]> {
    try {
      const { data, error } = await supabase
        .from("webhook_logs")
        .select("*")
        .eq("webhook_id", webhookId)
        .order("created_at", { ascending: false })
        .limit(100);

      if (error) {
        console.error("Error fetching webhook execution logs:", error);
        throw new Error(`Failed to fetch execution logs: ${error.message}`);
      }

      return data || [];
    } catch (error: any) {
      console.error("Error in getWebhookExecutionLogs:", error);
      throw error;
    }
  },

  async getAllWebhookExecutionLogs(userId: string): Promise<any[]> {
    try {
      const { data, error } = await supabase
        .from("webhook_logs")
        .select("*")
        .eq("user_id", userId)
        .order("created_at", { ascending: false })
        .limit(100);

      if (error) {
        console.error("Error fetching all webhook execution logs:", error);
        throw new Error(`Failed to fetch execution logs: ${error.message}`);
      }

      return data || [];
    } catch (error: any) {
      console.error("Error in getAllWebhookExecutionLogs:", error);
      throw error;
    }
  },

  async testWebhookAndLog(userId: string, webhookId: string, webhookUrl: string): Promise<{
    success: boolean;
    status?: number;
    message: string;
    testData?: any;
  }> {
    try {
      const result = await this.testWebhook(webhookUrl);

      await this.saveTestLog(
        userId,
        webhookId,
        {
          test: true,
          exchange: "TEST",
          indices: "BTC/USD",
          indicator: "TEST_SIGNAL",
          alert: "Webhook Test",
          price: 50000.0,
          action_binary: 1,
          rsi: 55.5,
          first_line: 0.5,
          mid_line: 0.0,
          slow_line: -0.5,
          time_unix: Math.floor(Date.now() / 1000),
          timestamp: new Date().toISOString(),
        },
        result.success ? "success" : "failed",
        result.status || 0,
        result.success ? "Webhook test successful" : (result.message || "Webhook test failed"),
        result.success ? undefined : result.message
      );

      return result;
    } catch (error: any) {
      console.error("Test webhook and log error:", error);
      
      try {
        await this.saveTestLog(
          userId,
          webhookId,
          { error: "Test execution failed" },
          "failed",
          0,
          "Test execution failed",
          error.message || "Unknown error"
        );
      } catch (saveError) {
        console.error("Failed to save error log:", saveError);
      }

      return {
        success: false,
        message: "Failed to test webhook and save log",
      };
    }
  },

  /**
   * Get webhook status logs from webhook_status_logs table
   */
  async getWebhookStatusLogs(webhookId: string): Promise<any[]> {
    try {
      // Break type inference completely by using intermediate any-typed variables
      const client: any = supabase;
      const table: any = client.from("webhook_status_logs");
      const select: any = table.select("*");
      const filter: any = select.eq("webhook_id", webhookId);
      const order: any = filter.order("created_at", { ascending: false });
      const limit: any = order.limit(100);
      const result = await limit as any;
      const { data, error } = result;
      
      if (error) {
        console.error("Error fetching status logs:", error);
        return [];
      }
      
      return data || [];
    } catch (error: any) {
      console.error("Error in getWebhookStatusLogs:", error);
      return [];
    }
  },
};