import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChevronLeft } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/router";

export default function BrokerAPIPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    apiUser: "",
    apiPassword: "",
    mobile: "",
    mpin: "",
    consumerKey: "",
    consumerSecret: "",
    tradePassword: "",
    pan: ""
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async () => {
    setLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    console.log("Form Data:", formData);
    setLoading(false);
    alert("Broker details updated successfully!");
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        
        {/* Main Card */}
        <Card className="bg-white border shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between border-b px-6 py-4">
            <CardTitle className="text-lg font-medium text-gray-800">
              Manage Broker & Exchanges - Kotak Securities (NeoAPI)
            </CardTitle>
            <Link href="/">
              <Button 
                variant="outline" 
                className="bg-[#D4AF37] hover:bg-[#C5A028] text-white border-none h-8 px-4 text-xs font-medium"
              >
                <ChevronLeft className="w-3 h-3 mr-1" />
                Back
              </Button>
            </Link>
          </CardHeader>
          
          <CardContent className="p-6 space-y-8">
            
            {/* Exchanges Section */}
            <div className="space-y-2">
              <Label className="text-sm font-semibold text-gray-700">Exchanges</Label>
              <Select defaultValue="all">
                <SelectTrigger className="w-full max-w-xl bg-white border-gray-200">
                  <SelectValue placeholder="Select Exchanges" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All selected (4)</SelectItem>
                  <SelectItem value="nse">NSE</SelectItem>
                  <SelectItem value="bse">BSE</SelectItem>
                  <SelectItem value="nfo">NFO</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Connect to Broker Section */}
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-gray-800">Connect to Broker</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
                <div className="space-y-2">
                  <Label htmlFor="apiUser" className="text-xs font-medium text-gray-600">API User</Label>
                  <Input 
                    id="apiUser" 
                    name="apiUser"
                    value={formData.apiUser}
                    onChange={handleInputChange}
                    className="h-10 bg-white border-gray-200 focus:border-gray-400 focus:ring-0"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="apiPassword" className="text-xs font-medium text-gray-600">API Password</Label>
                  <Input 
                    id="apiPassword" 
                    name="apiPassword"
                    type="password"
                    value={formData.apiPassword}
                    onChange={handleInputChange}
                    className="h-10 bg-white border-gray-200 focus:border-gray-400 focus:ring-0"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="mobile" className="text-xs font-medium text-gray-600">Mobile</Label>
                  <Input 
                    id="mobile" 
                    name="mobile"
                    value={formData.mobile}
                    onChange={handleInputChange}
                    className="h-10 bg-white border-gray-200 focus:border-gray-400 focus:ring-0"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="mpin" className="text-xs font-medium text-gray-600">MPin</Label>
                  <Input 
                    id="mpin" 
                    name="mpin"
                    type="password"
                    value={formData.mpin}
                    onChange={handleInputChange}
                    className="h-10 bg-white border-gray-200 focus:border-gray-400 focus:ring-0"
                  />
                </div>
              </div>
            </div>

            {/* Auto Login Section */}
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-gray-800">Auto Login</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
                <div className="space-y-2">
                  <Label htmlFor="consumerKey" className="text-xs font-medium text-gray-600">Consumer Key</Label>
                  <Input 
                    id="consumerKey" 
                    name="consumerKey"
                    value={formData.consumerKey}
                    onChange={handleInputChange}
                    className="h-10 bg-white border-gray-200 focus:border-gray-400 focus:ring-0"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="consumerSecret" className="text-xs font-medium text-gray-600">Consumer Secret</Label>
                  <Input 
                    id="consumerSecret" 
                    name="consumerSecret"
                    type="password"
                    value={formData.consumerSecret}
                    onChange={handleInputChange}
                    className="h-10 bg-white border-gray-200 focus:border-gray-400 focus:ring-0"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="tradePassword" className="text-xs font-medium text-gray-600">Trade Password</Label>
                  <Input 
                    id="tradePassword" 
                    name="tradePassword"
                    type="password"
                    value={formData.tradePassword}
                    onChange={handleInputChange}
                    className="h-10 bg-white border-gray-200 focus:border-gray-400 focus:ring-0"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="pan" className="text-xs font-medium text-gray-600">PAN</Label>
                  <Input 
                    id="pan" 
                    name="pan"
                    value={formData.pan}
                    onChange={handleInputChange}
                    className="h-10 bg-white border-gray-200 focus:border-gray-400 focus:ring-0"
                  />
                </div>
              </div>
            </div>

            {/* Footer Buttons */}
            <div className="flex justify-end gap-3 pt-4 border-t border-gray-100">
              <Button 
                variant="secondary" 
                onClick={() => router.back()}
                className="bg-gray-500 hover:bg-gray-600 text-white min-w-[100px]"
              >
                Cancel
              </Button>
              <Button 
                onClick={handleSubmit}
                className="bg-[#D4AF37] hover:bg-[#C5A028] text-white min-w-[100px]"
                disabled={loading}
              >
                {loading ? "Updating..." : "Update"}
              </Button>
            </div>

          </CardContent>
        </Card>
      </div>
    </div>
  );
}