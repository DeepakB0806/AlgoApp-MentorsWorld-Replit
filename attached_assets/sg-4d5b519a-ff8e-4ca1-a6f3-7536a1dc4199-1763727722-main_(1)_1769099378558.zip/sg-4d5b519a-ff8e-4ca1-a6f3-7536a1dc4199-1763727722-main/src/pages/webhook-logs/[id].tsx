import { useState, useEffect } from "react";
import { useRouter } from "next/router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, RefreshCw, Activity } from "lucide-react";
import Link from "next/link";
import { webhookLogService, WebhookLog } from "@/services/webhookLogService";
import { authService } from "@/services/authService";

export default function WebhookLogsPage() {
  const router = useRouter();
  const { id, indicator } = router.query;
  
  const [logs, setLogs] = useState<WebhookLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [autoRefresh, setAutoRefresh] = useState(true);

  useEffect(() => {
    if (!id || !indicator) return;
    
    loadLogs();
    
    let interval: NodeJS.Timeout;
    if (autoRefresh) {
      interval = setInterval(() => {
        loadLogs(true);
      }, 5000);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [id, indicator, autoRefresh]);

  const loadLogs = async (silent = false) => {
    if (!silent) setLoading(true);
    setError(null);
    
    try {
      const user = await authService.getCurrentUser();
      if (!user) {
        router.push("/login");
        return;
      }

      const indicatorName = indicator as string;
      const data = await webhookLogService.getWebhookLogs(indicatorName);
      setLogs(data);
    } catch (err: any) {
      setError(err.message || "Failed to load webhook logs");
    } finally {
      if (!silent) setLoading(false);
    }
  };

  const formatUnixTime = (unixTime: number | null) => {
    if (!unixTime) return "N/A";
    return new Date(unixTime * 1000).toLocaleString();
  };

  const formatLocalTime = (timestamp: string | null) => {
    if (!timestamp) return "N/A";
    return new Date(timestamp).toLocaleString();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Link href="/webhooks">
              <Button variant="ghost" className="text-slate-400 hover:text-white">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Webhooks
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-white">Webhook Logs</h1>
              <p className="text-slate-400">{indicator}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <Activity className={`w-4 h-4 ${autoRefresh ? "text-emerald-400 animate-pulse" : "text-slate-500"}`} />
              <span className="text-sm text-slate-400">
                {autoRefresh ? "Auto-refresh ON" : "Auto-refresh OFF"}
              </span>
              <Button
                size="sm"
                variant="outline"
                onClick={() => setAutoRefresh(!autoRefresh)}
                className="border-slate-700 text-slate-300"
              >
                {autoRefresh ? "Disable" : "Enable"}
              </Button>
            </div>
            <Button
              onClick={() => loadLogs()}
              variant="outline"
              className="border-slate-700 text-white hover:bg-slate-800"
              disabled={loading}
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${loading ? "animate-spin" : ""}`} />
              Refresh
            </Button>
          </div>
        </div>

        {error && (
          <Card className="bg-red-900/50 border-red-800 mb-6">
            <CardContent className="py-4">
              <p className="text-red-200">{error}</p>
            </CardContent>
          </Card>
        )}

        <Card className="bg-slate-900/50 border-slate-800">
          <CardHeader>
            <CardTitle className="text-white flex items-center justify-between">
              <span>Webhook Data Log</span>
              <Badge variant="outline" className="border-emerald-700 text-emerald-400">
                {logs.length} records
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loading && logs.length === 0 ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
                <p className="text-slate-400">Loading webhook logs...</p>
              </div>
            ) : logs.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-slate-400">No webhook data logged yet.</p>
                <p className="text-slate-500 text-sm mt-2">Data will appear here when webhooks are triggered.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="border-slate-800">
                      <TableHead className="text-slate-400">TIME AS PER HRNIK</TableHead>
                      <TableHead className="text-slate-400">LOCAL TIME</TableHead>
                      <TableHead className="text-slate-400">EXCHAN</TableHead>
                      <TableHead className="text-slate-400">INDICES</TableHead>
                      <TableHead className="text-slate-400">PRICE</TableHead>
                      <TableHead className="text-slate-400">ALERT</TableHead>
                      <TableHead className="text-slate-400">MODE</TableHead>
                      <TableHead className="text-slate-400">ACTION DONE</TableHead>
                      <TableHead className="text-slate-400">RSI</TableHead>
                      <TableHead className="text-slate-400">ST</TableHead>
                      <TableHead className="text-slate-400">LOCK STATE</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {logs.map((log) => (
                      <TableRow key={log.id} className="border-slate-800 hover:bg-slate-800/50">
                        <TableCell className="text-slate-300 text-xs">
                          {formatUnixTime(log.time_unix)}
                        </TableCell>
                        <TableCell className="text-slate-300 text-xs">
                          {formatLocalTime(log.local_time)}
                        </TableCell>
                        <TableCell className="text-slate-300">{log.exchange || "N/A"}</TableCell>
                        <TableCell className="text-white font-medium">{log.indices || "N/A"}</TableCell>
                        <TableCell className="text-emerald-400">
                          ₹{log.price?.toFixed(2) || "N/A"}
                        </TableCell>
                        <TableCell className="text-slate-300 text-sm">{log.alert || "N/A"}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="border-slate-700 text-slate-300 text-xs">
                            {log.mode || "N/A"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant={log.action_binary === 1 ? "default" : "secondary"}
                            className={log.action_binary === 1 ? "bg-emerald-600" : "bg-red-600"}
                          >
                            {log.action_binary === 1 ? "BUY" : log.action_binary === 0 ? "SELL" : "N/A"}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-slate-300">{log.rsi?.toFixed(2) || "N/A"}</TableCell>
                        <TableCell className="text-slate-300">{log.st?.toFixed(2) || "N/A"}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="border-purple-700 text-purple-400 text-xs">
                            {log.lock_state || "N/A"}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        {logs.length > 0 && (
          <Card className="bg-blue-950/30 border-blue-900/50 mt-6">
            <CardHeader>
              <CardTitle className="text-blue-400 text-sm">Additional Database Columns</CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-slate-400">
              <p className="mb-2">The table above shows the most relevant columns. Additional fields in database:</p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                <div>• INDICATOR</div>
                <div>• MODE DESC</div>
                <div>• FIRST PRICE</div>
                <div>• MID LINE</div>
                <div>• SLOW LINE</div>
                <div>• HT</div>
                <div>• RSI DIVERGENCE</div>
                <div>• ALERT DIVERGENCE</div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}