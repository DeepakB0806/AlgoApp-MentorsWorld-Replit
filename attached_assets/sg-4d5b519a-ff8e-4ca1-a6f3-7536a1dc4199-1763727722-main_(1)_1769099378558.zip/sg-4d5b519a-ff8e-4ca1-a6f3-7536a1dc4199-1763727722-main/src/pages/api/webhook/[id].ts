import type { NextApiRequest, NextApiResponse } from "next";
import { supabase } from "@/integrations/supabase/client";

interface WebhookPayload {
  action?: string;
  indicator?: string;
  price?: string | number;
  timestamp?: string | number;
  local_time?: string;
  exchange?: string;
  ticker?: string;
  rsi?: string | number;
  mode?: string | number;
  mode_desc?: string;
  fast_line?: string | number;
  mid_line?: string | number;
  slow_line?: string | number;
  supertrend?: string | number;
  half_trend?: string | number;
  rsi_scaled?: string | number;
  alert_system?: string;
  action_binary?: string | number;
  lock_state?: string;
  [key: string]: unknown;
}

interface WebhookResponse {
  success: boolean;
  message: string;
  data?: {
    webhookId: string;
    receivedAt: string;
    payload: WebhookPayload;
    logged: boolean;
  };
  error?: string;
}

// Mapping from JSON field names to database column names (lowercase to match actual schema)
const FIELD_TO_COLUMN_MAP: Record<string, string> = {
  action: "alert",
  indicator: "indicator",
  price: "price",
  timestamp: "time_as_per_hrnik",
  local_time: "local_time",
  exchange: "exchan",
  ticker: "indices",
  rsi: "rsi",
  mode: "mode",
  mode_desc: "mode_desc",
  fast_line: "first_price",
  mid_line: "mid_line",
  slow_line: "slow_line",
  supertrend: "st",
  half_trend: "ht",
  rsi_scaled: "rsi_divergence",
  alert_system: "alert_divergence",
  action_binary: "action_done",
  lock_state: "lock_state",
};

// Helper to safely extract query parameters (handling arrays)
const getQueryParam = (param: string | string[] | undefined): string | undefined => {
  if (!param) return undefined;
  if (Array.isArray(param)) return param[0];
  return param;
};

// Helper to parse numeric values
const parseNumeric = (value: unknown): number | null => {
  if (value === null || value === undefined) return null;
  const num = Number(value);
  return isNaN(num) ? null : num;
};

// Helper to parse timestamp
const parseTimestamp = (value: unknown): string | null => {
  if (!value) return null;
  
  // If it's a Unix timestamp in milliseconds
  if (typeof value === "number" || /^\d{13}$/.test(String(value))) {
    const timestamp = Number(value);
    return new Date(timestamp).toISOString();
  }
  
  // If it's already an ISO string
  if (typeof value === "string" && /^\d{4}-\d{2}-\d{2}/.test(value)) {
    return value;
  }
  
  return null;
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<WebhookResponse>
) {
  const { id } = req.query;
  const webhookId = Array.isArray(id) ? id[0] : id;

  // Accept both POST and GET methods
  if (req.method !== "POST" && req.method !== "GET") {
    return res.status(405).json({
      success: false,
      message: "Method not allowed",
      error: "Only POST and GET requests are accepted",
    });
  }

  if (!webhookId) {
    return res.status(400).json({
      success: false,
      message: "Invalid webhook ID",
      error: "Webhook ID is required",
    });
  }

  try {
    const receivedAt = new Date().toISOString();
    console.log("=== Webhook Received ===");
    console.log("Method:", req.method);
    console.log("Webhook ID:", webhookId);
    console.log("Received at:", receivedAt);

    let payload: WebhookPayload = {};
    
    // Parse JSON body from Make.com/TradingView
    if (req.body && typeof req.body === "object" && Object.keys(req.body).length > 0) {
      console.log("Raw Body:", JSON.stringify(req.body, null, 2));
      payload = req.body;
    } 
    // Fallback to query params (for GET requests or URL parameters)
    else if (req.query && Object.keys(req.query).length > 1) {
      console.log("Query Params:", JSON.stringify(req.query, null, 2));
      
      const params = req.query;
      Object.keys(params).forEach(key => {
        if (key !== "id") {
          payload[key] = getQueryParam(params[key]);
        }
      });
    } else {
      console.log("⚠️ No data received in body or query params");
    }

    console.log("Parsed Payload:", JSON.stringify(payload, null, 2));

    // Build database record with proper column names and type conversion
    const dbRecord: Record<string, any> = {
      webhook_id: webhookId,
      created_at: receivedAt,
    };

    for (const [jsonField, value] of Object.entries(payload)) {
      const columnName = FIELD_TO_COLUMN_MAP[jsonField];
      
      if (columnName) {
        // Apply proper type conversion based on column name
        if (columnName === "time_as_per_hrnik" || columnName === "local_time") {
          dbRecord[columnName] = parseTimestamp(value);
        } else if (columnName === "price" || columnName === "first_price" || 
                   columnName === "mid_line" || columnName === "slow_line" || 
                   columnName === "st" || columnName === "ht" || 
                   columnName === "rsi" || columnName === "rsi_divergence" || 
                   columnName === "alert_divergence") {
          dbRecord[columnName] = parseNumeric(value);
        } else {
          dbRecord[columnName] = value;
        }
      }
    }

    console.log("Database Record to Insert:", JSON.stringify(dbRecord, null, 2));

    // Insert data into webhook_status_logs table
    let logged = false;
    try {
      const { data, error: insertError } = await supabase
        .from("webhook_status_logs")
        .insert(dbRecord)
        .select();

      if (insertError) {
        console.error("❌ Failed to insert webhook data:", insertError);
        console.error("Error details:", JSON.stringify(insertError, null, 2));
      } else {
        logged = true;
        console.log("✅ Webhook data logged successfully!");
        console.log("Inserted record:", JSON.stringify(data, null, 2));
      }
    } catch (dbError) {
      console.error("❌ Exception inserting webhook data:", dbError);
    }

    // Log webhook execution status to webhook_logs table
    try {
      const { error: statusLogError } = await supabase
        .from("webhook_logs")
        .insert({
          webhook_id: webhookId,
          user_id: null,
          request_body: payload as any,
          response_body: {
            success: true,
            message: "Webhook received and processed successfully",
            logged: logged,
          } as any,
          status_code: 200,
          error_message: null,
        });

      if (statusLogError) {
        console.error("❌ Failed to log webhook status:", statusLogError);
      } else {
        console.log("✅ Webhook execution status logged");
      }
    } catch (statusError) {
      console.error("❌ Error logging webhook status:", statusError);
    }

    console.log("========================");

    return res.status(200).json({
      success: true,
      message: "Webhook received and processed successfully",
      data: {
        webhookId: webhookId,
        receivedAt,
        payload,
        logged,
      },
    });
  } catch (error) {
    console.error("❌ Error processing webhook:", error);
    
    // Log error to webhook_logs table
    try {
      if (typeof id === "string") {
        await supabase
          .from("webhook_logs")
          .insert({
            webhook_id: id,
            user_id: null,
            request_body: req.body || {},
            response_body: null,
            status_code: 500,
            error_message: error instanceof Error ? error.message : "Unknown error occurred",
          });
      }
    } catch (logError) {
      console.error("Failed to log error:", logError);
    }
    
    return res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error instanceof Error ? error.message : "Unknown error occurred",
    });
  }
}