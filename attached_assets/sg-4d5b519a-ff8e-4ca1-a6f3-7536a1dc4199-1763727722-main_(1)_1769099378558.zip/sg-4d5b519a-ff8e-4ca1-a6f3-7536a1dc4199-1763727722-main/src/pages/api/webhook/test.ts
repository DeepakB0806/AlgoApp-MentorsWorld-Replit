
import type { NextApiRequest, NextApiResponse } from "next";

interface TestResponse {
  status: string;
  message: string;
  timestamp: string;
  endpoints: {
    webhook: string;
    documentation: string;
  };
}

export default function handler(
  req: NextApiRequest,
  res: NextApiResponse<TestResponse>
) {
  res.status(200).json({
    status: "operational",
    message: "Webhook API is running",
    timestamp: new Date().toISOString(),
    endpoints: {
      webhook: "POST /api/webhook/[id]",
      documentation: "https://algo.mentorsworld.org/webhooks",
    },
  });
}
