import type { NextApiRequest, NextApiResponse } from "next";
import { supabase } from "@/integrations/supabase/client";

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { webhookUrl, userId, webhookId } = req.body;

  if (!webhookUrl) {
    return res.status(400).json({ error: "Webhook URL is required" });
  }

  if (!userId || !webhookId) {
    return res.status(400).json({ error: "User ID and Webhook ID are required" });
  }

  const testPayload = {
    test: true,
    exchange: "TEST",
    indices: "BTC/USD",
    indicator: "TEST_SIGNAL",
    alert: "Webhook Test",
    price: 50000.00,
    action_binary: 1,
    rsi: 55.5,
    first_line: 0.5,
    mid_line: 0.0,
    slow_line: -0.5,
    time_unix: Math.floor(Date.now() / 1000),
    timestamp: new Date().toISOString(),
  };

  try {
    // Send test request to webhook
    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(testPayload),
    });

    const responseData = await response.text();
    let parsedData;
    try {
      parsedData = JSON.parse(responseData);
    } catch {
      parsedData = responseData;
    }

    // Save test log to database
    const testLog = {
      user_id: userId,
      webhook_id: webhookId,
      test_payload: testPayload,
      status: response.ok ? "success" : "failed",
      status_code: response.status,
      response_message: typeof parsedData === "string" ? parsedData : JSON.stringify(parsedData),
      error_message: response.ok ? null : `HTTP ${response.status}: ${response.statusText}`,
      tested_at: new Date().toISOString(),
    };

    console.log("Saving test log:", testLog);

    const { data: savedLog, error: dbError } = await supabase
      .from("indicator_webhook_test_log")
      .insert([testLog])
      .select();

    if (dbError) {
      console.error("Error saving test log to database:", dbError);
      return res.status(200).json({
        success: response.ok,
        status: response.status,
        message: response.ok ? "Webhook test successful (log save failed)" : "Webhook test failed",
        testData: parsedData,
        logError: dbError.message,
      });
    }

    console.log("Test log saved successfully:", savedLog);

    return res.status(200).json({
      success: response.ok,
      status: response.status,
      message: response.ok ? "Webhook test successful" : "Webhook test failed",
      testData: parsedData,
      logSaved: true,
    });
  } catch (error) {
    console.error("Test webhook error:", error);
    
    // Try to save error log
    try {
      await supabase.from("indicator_webhook_test_log").insert({
        webhook_id: webhookId,
        user_id: userId,
        test_payload: { error: "Failed to send test" },
        status: "failed",
        status_code: 0,
        response_message: "",
        error_message: error instanceof Error ? error.message : "Unknown error",
        tested_at: new Date().toISOString(),
      });
    } catch (dbError) {
      console.error("Error saving error log:", dbError);
    }

    return res.status(500).json({
      success: false,
      message: "Failed to test webhook",
      error: error instanceof Error ? error.message : "Unknown error",
    });
  }
}