import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, Code, Settings, Play, Save, Trash2, Eye } from "lucide-react";
import Link from "next/link";

interface Strategy {
  id: string;
  name: string;
  description: string;
  code: string;
  type: string;
  status: "active" | "inactive";
  createdAt: string;
  parameters: StrategyParameter[];
}

interface StrategyParameter {
  name: string;
  value: string;
  type: "number" | "string" | "boolean";
}

const STRATEGY_TYPES = [
  { value: "momentum", label: "Momentum Strategy" },
  { value: "mean-reversion", label: "Mean Reversion" },
  { value: "breakout", label: "Breakout Strategy" },
  { value: "scalping", label: "Scalping" },
  { value: "custom", label: "Custom Strategy" },
];

const DEFAULT_CODE = `# Strategy Template
# Define your entry and exit conditions

def initialize(context):
    # Initialize your strategy parameters
    context.symbol = "RELIANCE"
    context.quantity = 1
    context.stop_loss = 0.02
    context.take_profit = 0.05

def handle_data(context, data):
    # Your strategy logic here
    current_price = data.current(context.symbol, 'price')
    
    # Example: Simple moving average crossover
    sma_short = data.history(context.symbol, 'price', 20, '1d').mean()
    sma_long = data.history(context.symbol, 'price', 50, '1d').mean()
    
    if sma_short > sma_long:
        # Buy signal
        order(context.symbol, context.quantity)
    elif sma_short < sma_long:
        # Sell signal
        order(context.symbol, -context.quantity)
`;

export default function StrategiesPage() {
  const [strategies, setStrategies] = useState<Strategy[]>([]);
  const [currentStrategy, setCurrentStrategy] = useState<Strategy>({
    id: "",
    name: "",
    description: "",
    code: DEFAULT_CODE,
    type: "",
    status: "inactive",
    createdAt: "",
    parameters: [
      { name: "stop_loss", value: "2", type: "number" },
      { name: "take_profit", value: "5", type: "number" },
      { name: "quantity", value: "1", type: "number" },
    ],
  });
  const [selectedStrategyId, setSelectedStrategyId] = useState<string | null>(null);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem("strategies");
    if (saved) {
      setStrategies(JSON.parse(saved) as Strategy[]);
    }
    setIsClient(true);
  }, []);

  const saveStrategy = () => {
    if (!currentStrategy.name.trim() || !currentStrategy.type) return;

    const strategy = {
      ...currentStrategy,
      id: currentStrategy.id || crypto.randomUUID(),
      createdAt: currentStrategy.createdAt || new Date().toISOString(),
    };

    let updated: Strategy[];
    if (currentStrategy.id) {
      updated = strategies.map((s) => (s.id === strategy.id ? strategy : s));
    } else {
      updated = [...strategies, strategy];
    }

    setStrategies(updated);
    localStorage.setItem("strategies", JSON.stringify(updated));
    resetForm();
  };

  const resetForm = () => {
    setCurrentStrategy({
      id: "",
      name: "",
      description: "",
      code: DEFAULT_CODE,
      type: "",
      status: "inactive",
      createdAt: "",
      parameters: [
        { name: "stop_loss", value: "2", type: "number" },
        { name: "take_profit", value: "5", type: "number" },
        { name: "quantity", value: "1", type: "number" },
      ],
    });
    setSelectedStrategyId(null);
  };

  const loadStrategy = (strategy: Strategy) => {
    setCurrentStrategy(strategy);
    setSelectedStrategyId(strategy.id);
  };

  const deleteStrategy = (id: string) => {
    const updated = strategies.filter((s) => s.id !== id);
    setStrategies(updated);
    localStorage.setItem("strategies", JSON.stringify(updated));
    if (selectedStrategyId === id) {
      resetForm();
    }
  };

  const toggleStrategyStatus = (id: string) => {
    const updated = strategies.map((s) =>
      s.id === id
        ? {
            ...s,
            status: (s.status === "active" ? "inactive" : "active") as "active" | "inactive",
          }
        : s
    );
    setStrategies(updated);
    localStorage.setItem("strategies", JSON.stringify(updated));
  };

  const updateParameter = (index: number, value: string) => {
    const updated = [...currentStrategy.parameters];
    updated[index].value = value;
    setCurrentStrategy({ ...currentStrategy, parameters: updated });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        <Link href="/">
          <Button variant="ghost" className="mb-6 text-slate-400 hover:text-white">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </Link>

        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Strategy Builder</h1>
          <p className="text-slate-400">
            Create, configure, and manage your automated trading strategies
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Tabs defaultValue="code" className="space-y-6">
              <TabsList className="bg-slate-900 border border-slate-800">
                <TabsTrigger value="code" className="data-[state=active]:bg-slate-800">
                  <Code className="w-4 h-4 mr-2" />
                  Code Editor
                </TabsTrigger>
                <TabsTrigger value="config" className="data-[state=active]:bg-slate-800">
                  <Settings className="w-4 h-4 mr-2" />
                  Configuration
                </TabsTrigger>
              </TabsList>

              <TabsContent value="code">
                <Card className="bg-slate-900/50 border-slate-800">
                  <CardHeader>
                    <CardTitle className="text-white">Strategy Code</CardTitle>
                    <CardDescription className="text-slate-400">
                      Write your strategy logic in Python
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Textarea
                      value={currentStrategy.code}
                      onChange={(e) =>
                        setCurrentStrategy({ ...currentStrategy, code: e.target.value })
                      }
                      placeholder="Enter your strategy code..."
                      className="bg-slate-800 border-slate-700 text-white font-mono min-h-[500px] text-sm"
                    />
                    <div className="mt-4 flex gap-2">
                      <Button
                        onClick={saveStrategy}
                        disabled={!currentStrategy.name || !currentStrategy.type}
                        className="bg-emerald-600 hover:bg-emerald-700"
                      >
                        <Save className="w-4 h-4 mr-2" />
                        Save Strategy
                      </Button>
                      <Button variant="outline" onClick={resetForm} className="border-slate-700">
                        Clear
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="config">
                <Card className="bg-slate-900/50 border-slate-800">
                  <CardHeader>
                    <CardTitle className="text-white">Strategy Configuration</CardTitle>
                    <CardDescription className="text-slate-400">
                      Set up your strategy details and parameters
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="strategy-name" className="text-slate-300">
                        Strategy Name
                      </Label>
                      <Input
                        id="strategy-name"
                        value={currentStrategy.name}
                        onChange={(e) =>
                          setCurrentStrategy({ ...currentStrategy, name: e.target.value })
                        }
                        placeholder="e.g., RSI Mean Reversion"
                        className="bg-slate-800 border-slate-700 text-white"
                      />
                    </div>

                    <div>
                      <Label htmlFor="strategy-description" className="text-slate-300">
                        Description
                      </Label>
                      <Textarea
                        id="strategy-description"
                        value={currentStrategy.description}
                        onChange={(e) =>
                          setCurrentStrategy({ ...currentStrategy, description: e.target.value })
                        }
                        placeholder="Describe your strategy..."
                        className="bg-slate-800 border-slate-700 text-white"
                      />
                    </div>

                    <div>
                      <Label htmlFor="strategy-type" className="text-slate-300">
                        Strategy Type
                      </Label>
                      <Select
                        value={currentStrategy.type}
                        onValueChange={(value) =>
                          setCurrentStrategy({ ...currentStrategy, type: value })
                        }
                      >
                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                          <SelectValue placeholder="Select strategy type" />
                        </SelectTrigger>
                        <SelectContent className="bg-slate-800 border-slate-700">
                          {STRATEGY_TYPES.map((type) => (
                            <SelectItem key={type.value} value={type.value} className="text-white">
                              {type.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="pt-4 border-t border-slate-700">
                      <h3 className="text-white font-semibold mb-4">Strategy Parameters</h3>
                      <div className="space-y-3">
                        {currentStrategy.parameters.map((param, index) => (
                          <div key={index} className="grid grid-cols-2 gap-3">
                            <div>
                              <Label className="text-slate-300 text-sm">{param.name}</Label>
                            </div>
                            <div>
                              <Input
                                type={param.type === "number" ? "number" : "text"}
                                value={param.value}
                                onChange={(e) => updateParameter(index, e.target.value)}
                                className="bg-slate-800 border-slate-700 text-white"
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <Button
                      onClick={saveStrategy}
                      disabled={!currentStrategy.name || !currentStrategy.type}
                      className="w-full bg-emerald-600 hover:bg-emerald-700"
                    >
                      <Save className="w-4 h-4 mr-2" />
                      Save Strategy
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white">Saved Strategies</CardTitle>
                <CardDescription className="text-slate-400">
                  {isClient ? `${strategies.length} ${strategies.length === 1 ? "strategy" : "strategies"} created` : "Loading..."}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {!isClient ? (
                   <p className="text-slate-500 text-center py-8">
                    Loading strategies...
                  </p>
                ) : strategies.length === 0 ? (
                  <p className="text-slate-500 text-center py-8">
                    No strategies yet. Create your first strategy!
                  </p>
                ) : (
                  <div className="space-y-3">
                    {strategies.map((strategy) => (
                      <div
                        key={strategy.id}
                        className={`bg-slate-800 rounded-lg p-4 border transition-all ${
                          selectedStrategyId === strategy.id
                            ? "border-purple-500"
                            : "border-slate-700"
                        }`}
                      >
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1">
                            <h3 className="text-white font-semibold">{strategy.name}</h3>
                            <p className="text-xs text-slate-400 mt-1">
                              {STRATEGY_TYPES.find((t) => t.value === strategy.type)?.label}
                            </p>
                          </div>
                          <div
                            className={`px-2 py-1 rounded text-xs ${
                              strategy.status === "active"
                                ? "bg-emerald-500/20 text-emerald-400"
                                : "bg-slate-700 text-slate-400"
                            }`}
                          >
                            {strategy.status}
                          </div>
                        </div>

                        {strategy.description && (
                          <p className="text-sm text-slate-400 mb-3">{strategy.description}</p>
                        )}

                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => loadStrategy(strategy)}
                            className="flex-1 border-slate-700 hover:bg-slate-700"
                          >
                            <Eye className="w-3 h-3 mr-1" />
                            View
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => toggleStrategyStatus(strategy.id)}
                            className={`border-slate-700 ${
                              strategy.status === "active"
                                ? "text-emerald-400 hover:text-emerald-300"
                                : ""
                            }`}
                          >
                            <Play className="w-3 h-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => deleteStrategy(strategy.id)}
                            className="border-red-900 text-red-400 hover:bg-red-950"
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="bg-purple-950/30 border-purple-900/50">
              <CardHeader>
                <CardTitle className="text-purple-400 text-sm">Strategy Tips</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-slate-400 space-y-2">
                <p>• Use initialize() to set up parameters</p>
                <p>• Implement handle_data() for strategy logic</p>
                <p>• Test thoroughly before activating</p>
                <p>• Monitor active strategies regularly</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
