import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useRouter } from "next/router";
import Link from "next/link";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Plus, Copy, Settings, Check, Trash2, CheckCircle, AlertCircle, ExternalLink, FileText, ChevronLeft, ChevronRight, Pencil, X } from "lucide-react";
import { settingsService } from "@/services/settingsService";
import { webhookLogService } from "@/services/webhookLogService";
import {
  Alert,
  AlertDescription,
} from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";

interface Webhook {
  id: string;
  name: string;
  url: string;
  createdAt: string;
}

interface TestLog {
  id: string;
  webhook_id: string;
  user_id: string;
  test_payload: any;
  status: string;
  status_code: number;
  response_message: string;
  error_message?: string;
  tested_at: string;
}

interface WebhookStatusLog {
  id: string;
  time_as_per_hrnik: string | null;
  exchan: string | null;
  indices: string | null;
  indicator: string | null;
  alert: string | null;
  price: number | null;
  local_time: string | null;
  mode: string | null;
  mode_desc: string | null;
  first_price: number | null;
  mid_line: number | null;
  slow_line: number | null;
  st: number | null;
  ht: number | null;
  rsi: number | null;
  rsi_divergence: number | null;
  alert_divergence: number | null;
  action_done: string | null;
  lock_state: string | null;
  narration_by_alina_the_astra_jsonn: string | null;
  created_at: string;
}

export default function WebhooksPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [domainName, setDomainName] = useState("");
  const [tempDomainName, setTempDomainName] = useState("");
  const [webhooks, setWebhooks] = useState<Webhook[]>([]);
  const [newWebhookName, setNewWebhookName] = useState("");
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [savingDomain, setSavingDomain] = useState(false);
  const [showDomainSuccess, setShowDomainSuccess] = useState(false);
  const [testingWebhook, setTestingWebhook] = useState<string | null>(null);
  const [testResults, setTestResults] = useState<{[key: string]: any}>({});
  
  // Edit state
  const [editingWebhookId, setEditingWebhookId] = useState<string | null>(null);
  const [editingWebhookName, setEditingWebhookName] = useState("");
  
  // Right panel state
  const [isPanelOpen, setIsPanelOpen] = useState(false);
  const [selectedWebhookId, setSelectedWebhookId] = useState<string | null>(null);
  const [testLogs, setTestLogs] = useState<TestLog[]>([]);
  const [statusLogs, setStatusLogs] = useState<WebhookStatusLog[]>([]);
  const [loadingLogs, setLoadingLogs] = useState(false);
  const [activeTab, setActiveTab] = useState<"test" | "status">("test");

  useEffect(() => {
    checkUser();
  }, []);

  useEffect(() => {
    if (isPanelOpen && selectedWebhookId) {
      loadLogsForWebhook(selectedWebhookId);
    }
  }, [isPanelOpen, selectedWebhookId, activeTab]);

  const checkUser = async () => {
    try {
      const {
        data: { session },
      } = await supabase.auth.getSession();

      if (!session) {
        router.push("/login");
        return;
      }

      setUser(session.user);
      await loadDomainName();
      await loadWebhooks();
    } catch (error) {
      console.error("Error checking user:", error);
    } finally {
      setLoading(false);
    }
  };

  const loadDomainName = async () => {
    try {
      const domain = await settingsService.getDomainName();
      if (domain) {
        setDomainName(domain);
        setTempDomainName(domain);
      }
    } catch (error) {
      console.error("Error loading domain name:", error);
    }
  };

  const saveDomainName = async () => {
    if (!user || !tempDomainName.trim()) return;

    setSavingDomain(true);
    try {
      await settingsService.saveDomainName(tempDomainName.trim());
      setDomainName(tempDomainName.trim());
      setShowDomainSuccess(true);
      setTimeout(() => setShowDomainSuccess(false), 3000);
    } catch (error) {
      console.error("Error saving domain name:", error);
      alert("Failed to save domain name. Please try again.");
    } finally {
      setSavingDomain(false);
    }
  };

  const loadWebhooks = async () => {
    try {
      const webhooksData = await settingsService.getWebhooks();
      const webhookList: Webhook[] = webhooksData.map((item) => ({
        id: item.id,
        name: item.name,
        url: domainName
          ? `https://${domainName}/api/webhook/${item.id}`
          : "",
        createdAt: item.createdAt,
      }));
      setWebhooks(webhookList);
    } catch (error) {
      console.error("Error loading webhooks:", error);
    }
  };

  const generateWebhook = async () => {
    if (!user || !domainName) {
      alert("Please save a domain name first!");
      return;
    }

    if (!newWebhookName.trim()) {
      alert("Please enter a webhook name!");
      return;
    }

    try {
      const webhookId = await settingsService.generateWebhookId();
      await settingsService.saveWebhook(webhookId, newWebhookName.trim());
      setNewWebhookName("");
      await loadWebhooks();
    } catch (error) {
      console.error("Error generating webhook:", error);
      alert("Failed to generate webhook. Please try again.");
    }
  };

  const deleteWebhook = async (webhookId: string) => {
    if (!user) return;

    if (!confirm("Are you sure you want to delete this webhook?")) return;

    try {
      await settingsService.deleteWebhook(webhookId);
      if (selectedWebhookId === webhookId) {
        setIsPanelOpen(false);
        setSelectedWebhookId(null);
      }
      await loadWebhooks();
    } catch (error) {
      console.error("Error deleting webhook. Please try again.");
    }
  };

  const startEditingWebhook = (webhookId: string, currentName: string) => {
    setEditingWebhookId(webhookId);
    setEditingWebhookName(currentName);
  };

  const cancelEditingWebhook = () => {
    setEditingWebhookId(null);
    setEditingWebhookName("");
  };

  const saveWebhookName = async (webhookId: string) => {
    if (!user || !editingWebhookName.trim()) return;

    try {
      await settingsService.updateWebhookName(webhookId, editingWebhookName.trim());
      setEditingWebhookId(null);
      setEditingWebhookName("");
      await loadWebhooks();
    } catch (error) {
      console.error("Error updating webhook name:", error);
      alert("Failed to update webhook name. Please try again.");
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleTestWebhook = async (webhookId: string, webhookUrl: string) => {
    if (!user) return;
    
    setTestingWebhook(webhookId);
    setTestResults((prev) => ({ ...prev, [webhookId]: null }));

    try {
      const response = await fetch("/api/test-webhook", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          webhookUrl,
          userId: user.id,
          webhookId,
        }),
      });

      const result = await response.json();
      console.log("Test webhook result:", result);
      setTestResults((prev) => ({ ...prev, [webhookId]: result }));

      if (result.success) {
        setTimeout(() => {
          setTestResults((prev) => {
            const updated = { ...prev };
            delete updated[webhookId];
            return updated;
          });
        }, 5000);
      }

      // Force immediate refresh of logs if this webhook's panel is open
      if (selectedWebhookId === webhookId && activeTab === "test") {
        console.log("Force refreshing test logs immediately...");
        // Fetch fresh logs directly without delay
        const logs = await webhookLogService.getTestLogs(webhookId);
        console.log("Fresh test logs fetched:", logs.length, "logs");
        setTestLogs(logs);
      }
    } catch (error) {
      console.error("Test webhook error:", error);
      setTestResults((prev) => ({
        ...prev,
        [webhookId]: {
          success: false,
          message: "Failed to test webhook",
        },
      }));
    } finally {
      setTestingWebhook(null);
    }
  };

  const loadLogsForWebhook = async (webhookId: string) => {
    console.log("Loading logs for webhook:", webhookId, "Tab:", activeTab);
    setLoadingLogs(true);
    try {
      if (activeTab === "test") {
        console.log("Fetching test logs...");
        const logs = await webhookLogService.getTestLogs(webhookId);
        console.log("Test logs fetched:", logs.length, "logs");
        setTestLogs(logs);
      } else {
        console.log("Fetching status logs...");
        const logs = await webhookLogService.getWebhookStatusLogs(webhookId);
        console.log("Status logs fetched:", logs.length, "logs");
        setStatusLogs(logs);
      }
    } catch (error) {
      console.error("Error loading logs:", error);
    } finally {
      setLoadingLogs(false);
    }
  };

  const openLogsPanel = (webhookId: string) => {
    setSelectedWebhookId(webhookId);
    setIsPanelOpen(true);
  };

  const closeLogsPanel = () => {
    setIsPanelOpen(false);
    setTimeout(() => {
      setSelectedWebhookId(null);
      setTestLogs([]);
      setStatusLogs([]);
    }, 300);
  };

  const getSelectedWebhook = () => {
    return webhooks.find(w => w.id === selectedWebhookId);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900 flex items-center justify-center">
        <div className="text-lg">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Indicator Webhook Management</h1>
          <p className="text-slate-300">
            Manage your trading indicator webhooks and monitor incoming signals
          </p>
        </div>

        <div className={`transition-all duration-300 ${isPanelOpen ? "mr-[600px]" : "mr-0"}`}>
          <div className="container mx-auto px-4 py-8 max-w-6xl">
            <Card className="mb-6">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="text-2xl">Webhook Management</CardTitle>
                  <CardDescription>
                    Configure your domain and generate webhook URLs
                  </CardDescription>
                </div>
                <div className="flex gap-2">
                  <Link href="/">
                    <Button variant="outline" size="sm">
                      <ArrowLeft className="mr-2 h-4 w-4" />
                      Back to Dashboard
                    </Button>
                  </Link>
                </div>
              </CardHeader>
            </Card>

            {/* Domain Configuration */}
            <Card className="mb-6">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  <CardTitle>Domain Configuration</CardTitle>
                </div>
                <CardDescription>
                  Set your application domain to generate webhook URLs
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="domain">Domain Name</Label>
                    <div className="flex gap-2">
                      <div className="flex-1 flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">https://</span>
                        <Input
                          id="domain"
                          placeholder="algoapp.mentorsworld.org"
                          value={tempDomainName}
                          onChange={(e) => setTempDomainName(e.target.value)}
                          className="flex-1"
                        />
                      </div>
                      <Button
                        onClick={saveDomainName}
                        disabled={savingDomain || !tempDomainName.trim()}
                      >
                        {savingDomain ? "Saving..." : "Save Domain"}
                      </Button>
                    </div>
                  </div>

                  {showDomainSuccess && (
                    <Alert className="bg-green-50 border-green-200 dark:bg-green-950 dark:border-green-800">
                      <Check className="h-4 w-4 text-green-600 dark:text-green-400" />
                      <AlertDescription className="text-green-800 dark:text-green-200">
                        Domain saved successfully! You can now generate webhooks.
                      </AlertDescription>
                    </Alert>
                  )}

                  {domainName && (
                    <div className="text-sm text-muted-foreground">
                      Current domain: <span className="font-mono bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded">https://{domainName}</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Generate New Webhook */}
            {domainName && (
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Generate New Webhook</CardTitle>
                  <CardDescription>
                    Create a new webhook for your trading strategies
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-2">
                    <Input
                      placeholder="Enter webhook name (e.g., BTC Scalping Strategy)"
                      value={newWebhookName}
                      onChange={(e) => setNewWebhookName(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && generateWebhook()}
                      className="flex-1"
                    />
                    <Button onClick={generateWebhook} disabled={!newWebhookName.trim()}>
                      <Plus className="mr-2 h-4 w-4" />
                      Generate Webhook
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Webhooks List */}
            {webhooks.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Indicator Webhooks</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {webhooks.map((webhook) => {
                      const webhookUrl = `https://${domainName}/api/webhook/${webhook.id}`;
                      const testResult = testResults[webhook.id];
                      const isEditing = editingWebhookId === webhook.id;

                      return (
                        <div
                          key={webhook.id}
                          className="p-4 border rounded-lg space-y-3"
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              {isEditing ? (
                                <div className="flex items-center gap-2 mb-2">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => saveWebhookName(webhook.id)}
                                    className="h-8 w-8 p-0"
                                  >
                                    <Check className="h-4 w-4 text-green-600" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={cancelEditingWebhook}
                                    className="h-8 w-8 p-0"
                                  >
                                    <X className="h-4 w-4 text-red-600" />
                                  </Button>
                                  <Input
                                    value={editingWebhookName}
                                    onChange={(e) => setEditingWebhookName(e.target.value)}
                                    onKeyDown={(e) => {
                                      if (e.key === "Enter") saveWebhookName(webhook.id);
                                      if (e.key === "Escape") cancelEditingWebhook();
                                    }}
                                    className="flex-1 font-semibold text-lg"
                                    autoFocus
                                  />
                                </div>
                              ) : (
                                <div className="flex items-center gap-2 mb-2">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => startEditingWebhook(webhook.id, webhook.name)}
                                    className="h-8 w-8 p-0"
                                  >
                                    <Pencil className="h-4 w-4" />
                                  </Button>
                                  <h3 className="font-semibold text-lg">
                                    {webhook.name}
                                  </h3>
                                </div>
                              )}
                              <p className="text-sm text-muted-foreground mt-1">
                                Created: {new Date(webhook.createdAt).toLocaleString()}
                              </p>
                              <div className="mt-2 p-2 bg-muted rounded font-mono text-sm break-all">
                                {webhookUrl}
                              </div>
                            </div>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                if (isPanelOpen && selectedWebhookId === webhook.id) {
                                  closeLogsPanel();
                                } else {
                                  openLogsPanel(webhook.id);
                                }
                              }}
                              className="ml-4 flex-shrink-0"
                            >
                              {isPanelOpen && selectedWebhookId === webhook.id ? (
                                <>
                                  <ChevronLeft className="h-4 w-4 mr-2" />
                                  Close Logs
                                </>
                              ) : (
                                <>
                                  <ChevronRight className="h-4 w-4 mr-2" />
                                  View Logs
                                </>
                              )}
                            </Button>
                          </div>

                          {testResult && (
                            <div
                              className={`p-3 rounded-lg flex items-start gap-2 ${
                                testResult.success
                                  ? "bg-green-50 border border-green-200 dark:bg-green-950 dark:border-green-800"
                                  : "bg-red-50 border border-red-200 dark:bg-red-950 dark:border-red-800"
                              }`}
                            >
                              {testResult.success ? (
                                <CheckCircle className="h-5 w-5 text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5" />
                              ) : (
                                <AlertCircle className="h-5 w-5 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
                              )}
                              <div className="flex-1">
                                <p
                                  className={`text-sm font-medium ${
                                    testResult.success ? "text-green-800 dark:text-green-200" : "text-red-800 dark:text-red-200"
                                  }`}
                                >
                                  {testResult.message}
                                </p>
                                {testResult.status && (
                                  <p className="text-xs text-muted-foreground mt-1">
                                    Status: {testResult.status}
                                  </p>
                                )}
                              </div>
                            </div>
                          )}

                          <div className="flex gap-2 flex-wrap">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => copyToClipboard(webhookUrl, webhook.id)}
                            >
                              {copiedId === webhook.id ? (
                                <>
                                  <CheckCircle className="h-4 w-4 mr-2" />
                                  Copied!
                                </>
                              ) : (
                                <>
                                  <Copy className="h-4 w-4 mr-2" />
                                  Copy URL
                                </>
                              )}
                            </Button>

                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleTestWebhook(webhook.id, webhookUrl)}
                              disabled={testingWebhook === webhook.id}
                            >
                              <ExternalLink className="h-4 w-4 mr-2" />
                              {testingWebhook === webhook.id ? "Testing..." : "Test Webhook"}
                            </Button>

                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => deleteWebhook(webhook.id)}
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              Delete
                            </Button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Empty State */}
            {domainName && webhooks.length === 0 && (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <div className="text-center space-y-2">
                    <h3 className="text-lg font-semibold">No webhooks yet</h3>
                    <p className="text-sm text-muted-foreground">
                      Generate your first webhook to start receiving trading signals
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Collapsible Right Panel */}
        <div
          className={`fixed top-0 right-0 h-full w-[600px] bg-background border-l shadow-2xl transform transition-transform duration-300 ease-in-out z-50 ${
            isPanelOpen ? "translate-x-0" : "translate-x-full"
          }`}
        >
          <div className="flex flex-col h-full">
            {/* Panel Header */}
            <div className="p-4 border-b flex items-center justify-between bg-muted/50">
              <div className="flex-1">
                <h2 className="text-lg font-semibold">Webhook Logs</h2>
                {getSelectedWebhook() && (
                  <p className="text-sm text-muted-foreground mt-1">
                    {getSelectedWebhook()?.name}
                  </p>
                )}
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => selectedWebhookId && loadLogsForWebhook(selectedWebhookId)}
                  disabled={loadingLogs}
                >
                  {loadingLogs ? "Refreshing..." : "Refresh"}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={closeLogsPanel}
                  className="ml-2"
                >
                  <ChevronRight className="h-5 w-5" />
                </Button>
              </div>
            </div>

            {/* Tabs */}
            <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "test" | "status")} className="flex-1 flex flex-col">
              <TabsList className="mx-4 mt-4">
                <TabsTrigger value="test" className="flex-1">Test Logs</TabsTrigger>
                <TabsTrigger value="status" className="flex-1">Webhook Status Logs</TabsTrigger>
              </TabsList>

              {/* Test Logs Tab */}
              <TabsContent value="test" className="flex-1 overflow-hidden mt-4">
                <div className="h-full overflow-y-auto px-4 pb-4">
                  {loadingLogs ? (
                    <div className="flex items-center justify-center py-12">
                      <div className="text-muted-foreground">Loading test logs...</div>
                    </div>
                  ) : testLogs.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-12 text-center">
                      <FileText className="h-12 w-12 text-muted-foreground mb-4" />
                      <h3 className="font-semibold mb-2">No Test Logs</h3>
                      <p className="text-sm text-muted-foreground">
                        Click "Test Webhook" to create test logs
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {testLogs.map((log) => (
                        <div
                          key={log.id}
                          className={`p-4 rounded-lg border ${
                            log.status === "success"
                              ? "bg-green-50 border-green-200 dark:bg-green-950/30 dark:border-green-800"
                              : "bg-red-50 border-red-200 dark:bg-red-950/30 dark:border-red-800"
                          }`}
                        >
                          <div className="flex items-start justify-between mb-3">
                            <div className="flex items-center gap-2">
                              {log.status === "success" ? (
                                <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
                              ) : (
                                <AlertCircle className="h-4 w-4 text-red-600 dark:text-red-400" />
                              )}
                              <span className={`text-sm font-medium ${
                                log.status === "success"
                                  ? "text-green-800 dark:text-green-200" 
                                  : "text-red-800 dark:text-red-200"
                              }`}>
                                {log.status === "success" ? "Success" : "Failed"}
                              </span>
                              <span className="text-xs text-muted-foreground">
                                Status: {log.status_code}
                              </span>
                            </div>
                            <span className="text-xs text-muted-foreground">
                              {new Date(log.tested_at).toLocaleString()}
                            </span>
                          </div>
                          
                          <div className="space-y-2 text-xs">
                            {log.response_message && (
                              <div>
                                <span className="font-semibold">Response:</span>
                                <p className="mt-1 text-muted-foreground">{log.response_message}</p>
                              </div>
                            )}
                            
                            {log.error_message && (
                              <div>
                                <span className="font-semibold text-red-600 dark:text-red-400">Error:</span>
                                <p className="mt-1 text-red-600 dark:text-red-400">{log.error_message}</p>
                              </div>
                            )}
                            
                            <div>
                              <span className="font-semibold">Test Payload:</span>
                              <pre className="mt-1 p-2 bg-muted rounded text-xs overflow-x-auto">
                                {JSON.stringify(log.test_payload, null, 2)}
                              </pre>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </TabsContent>

              {/* Webhook Status Logs Tab - Database Table Display */}
              <TabsContent value="status" className="flex-1 overflow-hidden mt-4">
                <div className="h-full overflow-y-auto px-4 pb-4">
                  {loadingLogs ? (
                    <div className="flex items-center justify-center py-12">
                      <div className="text-muted-foreground">Loading status logs...</div>
                    </div>
                  ) : statusLogs.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-12 text-center">
                      <FileText className="h-12 w-12 text-muted-foreground mb-4" />
                      <h3 className="font-semibold mb-2">No Status Logs</h3>
                      <p className="text-sm text-muted-foreground">
                        No webhook executions recorded yet
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {statusLogs.map((log) => (
                        <div
                          key={log.id}
                          className="p-4 rounded-lg border bg-white dark:bg-slate-900"
                        >
                          <div className="flex items-start justify-between mb-4">
                            <span className="text-xs text-muted-foreground">
                              {new Date(log.created_at).toLocaleString()}
                            </span>
                          </div>
                          
                          {/* Database Table Display */}
                          <div className="bg-white dark:bg-slate-900 rounded-lg border overflow-hidden">
                            <table className="w-full text-xs">
                              <thead>
                                <tr className="bg-slate-100 dark:bg-slate-800">
                                  <th className="text-left p-2 font-semibold border-r">Column Name</th>
                                  <th className="text-left p-2 font-semibold">Value</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr className="border-b hover:bg-muted/50">
                                  <td className="font-semibold p-2 bg-muted/30 border-r w-1/3">time_as_per_hrnik</td>
                                  <td className="p-2 font-mono">{log.time_as_per_hrnik ? new Date(log.time_as_per_hrnik).toLocaleString() : "-"}</td>
                                </tr>
                                <tr className="border-b hover:bg-muted/50">
                                  <td className="font-semibold p-2 bg-muted/30 border-r">exchan</td>
                                  <td className="p-2 font-mono">{log.exchan || "-"}</td>
                                </tr>
                                <tr className="border-b hover:bg-muted/50">
                                  <td className="font-semibold p-2 bg-muted/30 border-r">indices</td>
                                  <td className="p-2 font-mono">{log.indices || "-"}</td>
                                </tr>
                                <tr className="border-b hover:bg-muted/50">
                                  <td className="font-semibold p-2 bg-muted/30 border-r">indicator</td>
                                  <td className="p-2 font-mono">{log.indicator || "-"}</td>
                                </tr>
                                <tr className="border-b hover:bg-muted/50">
                                  <td className="font-semibold p-2 bg-muted/30 border-r">alert</td>
                                  <td className="p-2 font-mono">{log.alert || "-"}</td>
                                </tr>
                                <tr className="border-b hover:bg-muted/50">
                                  <td className="font-semibold p-2 bg-muted/30 border-r">price</td>
                                  <td className="p-2 font-mono">{log.price !== null ? log.price : "-"}</td>
                                </tr>
                                <tr className="border-b hover:bg-muted/50">
                                  <td className="font-semibold p-2 bg-muted/30 border-r">local_time</td>
                                  <td className="p-2 font-mono">{log.local_time ? new Date(log.local_time).toLocaleString() : "-"}</td>
                                </tr>
                                <tr className="border-b hover:bg-muted/50">
                                  <td className="font-semibold p-2 bg-muted/30 border-r">mode</td>
                                  <td className="p-2 font-mono">{log.mode || "-"}</td>
                                </tr>
                                <tr className="border-b hover:bg-muted/50">
                                  <td className="font-semibold p-2 bg-muted/30 border-r">mode_desc</td>
                                  <td className="p-2 font-mono">{log.mode_desc || "-"}</td>
                                </tr>
                                <tr className="border-b hover:bg-muted/50">
                                  <td className="font-semibold p-2 bg-muted/30 border-r">first_price</td>
                                  <td className="p-2 font-mono">{log.first_price !== null ? log.first_price : "-"}</td>
                                </tr>
                                <tr className="border-b hover:bg-muted/50">
                                  <td className="font-semibold p-2 bg-muted/30 border-r">mid_line</td>
                                  <td className="p-2 font-mono">{log.mid_line !== null ? log.mid_line : "-"}</td>
                                </tr>
                                <tr className="border-b hover:bg-muted/50">
                                  <td className="font-semibold p-2 bg-muted/30 border-r">slow_line</td>
                                  <td className="p-2 font-mono">{log.slow_line !== null ? log.slow_line : "-"}</td>
                                </tr>
                                <tr className="border-b hover:bg-muted/50">
                                  <td className="font-semibold p-2 bg-muted/30 border-r">st</td>
                                  <td className="p-2 font-mono">{log.st !== null ? log.st : "-"}</td>
                                </tr>
                                <tr className="border-b hover:bg-muted/50">
                                  <td className="font-semibold p-2 bg-muted/30 border-r">ht</td>
                                  <td className="p-2 font-mono">{log.ht !== null ? log.ht : "-"}</td>
                                </tr>
                                <tr className="border-b hover:bg-muted/50">
                                  <td className="font-semibold p-2 bg-muted/30 border-r">rsi</td>
                                  <td className="p-2 font-mono">{log.rsi !== null ? log.rsi : "-"}</td>
                                </tr>
                                <tr className="border-b hover:bg-muted/50">
                                  <td className="font-semibold p-2 bg-muted/30 border-r">rsi_divergence</td>
                                  <td className="p-2 font-mono">{log.rsi_divergence !== null ? log.rsi_divergence : "-"}</td>
                                </tr>
                                <tr className="border-b hover:bg-muted/50">
                                  <td className="font-semibold p-2 bg-muted/30 border-r">alert_divergence</td>
                                  <td className="p-2 font-mono">{log.alert_divergence !== null ? log.alert_divergence : "-"}</td>
                                </tr>
                                <tr className="border-b hover:bg-muted/50">
                                  <td className="font-semibold p-2 bg-muted/30 border-r">action_done</td>
                                  <td className="p-2 font-mono">{log.action_done || "-"}</td>
                                </tr>
                                <tr className="border-b hover:bg-muted/50">
                                  <td className="font-semibold p-2 bg-muted/30 border-r">lock_state</td>
                                  <td className="p-2 font-mono">{log.lock_state || "-"}</td>
                                </tr>
                                <tr className="hover:bg-muted/50">
                                  <td className="font-semibold p-2 bg-muted/30 border-r">narration_by_alina_the_astra_jsonn</td>
                                  <td className="p-2 font-mono text-xs break-words max-w-xs">{log.narration_by_alina_the_astra_jsonn || "-"}</td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}