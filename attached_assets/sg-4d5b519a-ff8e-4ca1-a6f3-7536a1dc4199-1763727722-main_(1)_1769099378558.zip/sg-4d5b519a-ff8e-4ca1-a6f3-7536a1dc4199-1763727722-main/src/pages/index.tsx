import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, BarChart3, Activity, ArrowRight, LogIn, User, LogOut } from "lucide-react";
import Link from "next/link";
import { authService, AuthUser } from "@/services/authService";

export default function Home() {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkAuth();

    // Listen for auth changes
    const { data: { subscription } } = authService.onAuthStateChange(() => {
      checkAuth();
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const checkAuth = async () => {
    const currentUser = await authService.getCurrentUser();
    setUser(currentUser);
    setLoading(false);
  };

  const handleLogout = async () => {
    await authService.signOut();
    setUser(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-white">AlgoTrading Platform</h1>
            <div className="flex items-center gap-3">
              {loading ? (
                <div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-600 border-t-white"></div>
              ) : user ? (
                <>
                  <div className="flex items-center gap-2 text-white">
                    <User className="w-5 h-5" />
                    <span className="text-sm">{user.email}</span>
                  </div>
                  <Button
                    onClick={handleLogout}
                    variant="outline"
                    size="sm"
                    className="border-slate-700 text-white hover:bg-slate-800"
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                  </Button>
                </>
              ) : (
                <Link href="/login">
                  <Button
                    size="sm"
                    className="bg-emerald-600 hover:bg-emerald-700 text-white"
                  >
                    <LogIn className="w-4 h-4 mr-2" />
                    Sign In
                  </Button>
                </Link>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Rest of existing content */}
      <div className="container mx-auto px-4 py-12">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h2 className="text-5xl font-bold text-white mb-4">
            Automated Trading Made Simple
          </h2>
          <p className="text-xl text-slate-400 max-w-2xl mx-auto mb-8">
            Create, backtest, and deploy trading strategies with our powerful algorithmic trading platform
          </p>
          {!user && (
            <Link href="/login">
              <Button size="lg" className="bg-emerald-600 hover:bg-emerald-700 text-white">
                Get Started
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          )}
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <Card className="bg-slate-900/50 border-slate-800 hover:border-emerald-600 transition-colors">
            <CardHeader>
              <TrendingUp className="w-12 h-12 text-emerald-400 mb-4" />
              <CardTitle className="text-white">Strategy Builder</CardTitle>
              <CardDescription className="text-slate-400">
                Create custom trading strategies with our intuitive interface
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="bg-slate-900/50 border-slate-800 hover:border-blue-600 transition-colors">
            <CardHeader>
              <BarChart3 className="w-12 h-12 text-blue-400 mb-4" />
              <CardTitle className="text-white">Backtesting</CardTitle>
              <CardDescription className="text-slate-400">
                Test your strategies with historical data before going live
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="bg-slate-900/50 border-slate-800 hover:border-purple-600 transition-colors">
            <CardHeader>
              <Activity className="w-12 h-12 text-purple-400 mb-4" />
              <CardTitle className="text-white">Live Trading</CardTitle>
              <CardDescription className="text-slate-400">
                Execute trades automatically with integrated broker APIs
              </CardDescription>
            </CardHeader>
          </Card>
        </div>

        {/* Quick Links */}
        {user && (
          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <Link href="/strategies">
              <Card className="bg-slate-900/50 border-slate-800 hover:border-emerald-600 transition-all cursor-pointer">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xl font-semibold text-white mb-2">Strategies</h3>
                      <p className="text-slate-400">Manage your trading strategies</p>
                    </div>
                    <ArrowRight className="text-emerald-400 w-6 h-6" />
                  </div>
                </CardContent>
              </Card>
            </Link>

            <Link href="/dashboard">
              <Card className="bg-slate-900/50 border-slate-800 hover:border-blue-600 transition-all cursor-pointer">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xl font-semibold text-white mb-2">Dashboard</h3>
                      <p className="text-slate-400">View live trading dashboard</p>
                    </div>
                    <ArrowRight className="text-blue-400 w-6 h-6" />
                  </div>
                </CardContent>
              </Card>
            </Link>

            <Link href="/webhooks">
              <Card className="bg-slate-900/50 border-slate-800 hover:border-purple-600 transition-all cursor-pointer">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xl font-semibold text-white mb-2">Webhooks</h3>
                      <p className="text-slate-400">Configure trading webhooks</p>
                    </div>
                    <ArrowRight className="text-purple-400 w-6 h-6" />
                  </div>
                </CardContent>
              </Card>
            </Link>

            <Link href="/broker-api">
              <Card className="bg-slate-900/50 border-slate-800 hover:border-yellow-600 transition-all cursor-pointer">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xl font-semibold text-white mb-2">Broker & Exchanges</h3>
                      <p className="text-slate-400">Manage broker credentials</p>
                    </div>
                    <ArrowRight className="text-yellow-400 w-6 h-6" />
                  </div>
                </CardContent>
              </Card>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
