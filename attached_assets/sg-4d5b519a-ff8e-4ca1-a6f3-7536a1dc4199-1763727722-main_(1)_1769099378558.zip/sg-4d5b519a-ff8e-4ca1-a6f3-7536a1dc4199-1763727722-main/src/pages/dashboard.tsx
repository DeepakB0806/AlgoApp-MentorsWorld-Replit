import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ArrowLeft, TrendingUp, TrendingDown, DollarSign, Activity, PlusCircle, LogOut, RefreshCw } from "lucide-react";
import Link from "next/link";
import { tradingService, LoginCredentials, OrderParams, Position, Order, Holding } from "@/services/tradingService";

export default function DashboardPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loginData, setLoginData] = useState<LoginCredentials>({
    consumer_key: "",
    consumer_secret: "",
    mobile_number: "",
    password: "",
    mpin: "",
    totp_secret: "",
  });

  const [positions, setPositions] = useState<Position[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [holdings, setHoldings] = useState<Holding[]>([]);
  const [margins, setMargins] = useState<any>(null);
  const [portfolioSummary, setPortfolioSummary] = useState({
    totalPnL: 0,
    dayPnL: 0,
    totalValue: 0,
  });

  const [orderForm, setOrderForm] = useState<OrderParams>({
    exchange_segment: "nse_cm",
    product: "CNC",
    price: "",
    order_type: "L",
    quantity: "",
    validity: "DAY",
    trading_symbol: "",
    transaction_type: "B",
    amo: "NO",
    disclosed_quantity: "0",
    market_protection: "0",
    pf: "N",
    trigger_price: "0",
  });

  useEffect(() => {
    const sessionId = tradingService.getSessionId();
    if (sessionId) {
      setIsAuthenticated(true);
      loadDashboardData();
    }
  }, []);

  const handleLogin = async () => {
    setLoading(true);
    try {
      const response = await tradingService.login(loginData);
      if (response.success) {
        setIsAuthenticated(true);
        await loadDashboardData();
      }
    } catch (error: any) {
      alert(`Login failed: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await tradingService.logout();
      setIsAuthenticated(false);
      setPositions([]);
      setOrders([]);
      setHoldings([]);
      setMargins(null);
    } catch (error: any) {
      alert(`Logout failed: ${error.message}`);
    }
  };

  const loadDashboardData = async () => {
    setLoading(true);
    try {
      const [positionsData, ordersData, holdingsData, marginsData] = await Promise.all([
        tradingService.getPositions().catch(() => []),
        tradingService.getOrders().catch(() => []),
        tradingService.getHoldings().catch(() => []),
        tradingService.getMargins().catch(() => null),
      ]);

      const positionsArray = Array.isArray(positionsData) ? positionsData : [];
      const holdingsArray = Array.isArray(holdingsData) ? holdingsData : [];

      setPositions(positionsArray);
      setOrders(ordersData);
      setHoldings(holdingsArray);
      setMargins(marginsData);

      const totalPnL = positionsArray.reduce((sum: number, pos: Position) => sum + (pos.pnl || 0), 0);
      const totalValue = holdingsArray.reduce(
        (sum: number, holding: Holding) => sum + (holding.current_price || 0) * (holding.quantity || 0),
        0
      );

      setPortfolioSummary({
        totalPnL,
        dayPnL: totalPnL,
        totalValue,
      });
    } catch (error: any) {
      console.error("Failed to load dashboard data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handlePlaceOrder = async () => {
    setLoading(true);
    try {
      await tradingService.placeOrder(orderForm);
      alert("Order placed successfully!");
      await loadDashboardData();
      setOrderForm({
        ...orderForm,
        trading_symbol: "",
        quantity: "",
        price: "",
      });
    } catch (error: any) {
      alert(`Order failed: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleCancelOrder = async (orderId: string) => {
    if (!confirm("Are you sure you want to cancel this order?")) return;
    
    setLoading(true);
    try {
      await tradingService.cancelOrder(orderId);
      alert("Order cancelled successfully!");
      await loadDashboardData();
    } catch (error: any) {
      alert(`Cancel failed: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 flex items-center justify-center p-4">
        <Card className="w-full max-w-md bg-slate-900/50 border-slate-800">
          <CardHeader>
            <CardTitle className="text-white text-2xl">Login to Trading Dashboard</CardTitle>
            <CardDescription className="text-slate-400">
              Enter your Kotak Neo credentials to access live trading
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="text-slate-300">Consumer Key</Label>
              <Input
                type="text"
                value={loginData.consumer_key}
                onChange={(e) => setLoginData({ ...loginData, consumer_key: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white"
                placeholder="Enter consumer key"
              />
            </div>

            <div>
              <Label className="text-slate-300">Consumer Secret</Label>
              <Input
                type="password"
                value={loginData.consumer_secret}
                onChange={(e) => setLoginData({ ...loginData, consumer_secret: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white"
                placeholder="Enter consumer secret"
              />
            </div>

            <div>
              <Label className="text-slate-300">Mobile Number</Label>
              <Input
                type="text"
                value={loginData.mobile_number}
                onChange={(e) => setLoginData({ ...loginData, mobile_number: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white"
                placeholder="Enter mobile number"
              />
            </div>

            <div>
              <Label className="text-slate-300">Password</Label>
              <Input
                type="password"
                value={loginData.password}
                onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white"
                placeholder="Enter password"
              />
            </div>

            <div>
              <Label className="text-slate-300">MPIN</Label>
              <Input
                type="password"
                value={loginData.mpin}
                onChange={(e) => setLoginData({ ...loginData, mpin: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white"
                placeholder="Enter MPIN"
                maxLength={6}
              />
            </div>

            <div>
              <Label className="text-slate-300">TOTP Secret (Optional)</Label>
              <Input
                type="text"
                value={loginData.totp_secret}
                onChange={(e) => setLoginData({ ...loginData, totp_secret: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white"
                placeholder="Enter TOTP secret for auto-login"
              />
            </div>

            <Button
              onClick={handleLogin}
              disabled={loading || !loginData.consumer_key || !loginData.consumer_secret || !loginData.mobile_number || !loginData.password || !loginData.mpin}
              className="w-full bg-emerald-600 hover:bg-emerald-700"
            >
              {loading ? "Authenticating..." : "Login to Dashboard"}
            </Button>

            <Link href="/">
              <Button variant="ghost" className="w-full text-slate-400 hover:text-white">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800">
      <div className="container mx-auto px-4 py-6 max-w-7xl">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold text-white">Trading Dashboard</h1>
            <p className="text-slate-400">Live trading with Kotak Neo</p>
          </div>
          <div className="flex gap-2">
            <Button
              onClick={loadDashboardData}
              variant="outline"
              className="border-slate-700 text-white hover:bg-slate-800"
              disabled={loading}
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${loading ? "animate-spin" : ""}`} />
              Refresh
            </Button>
            <Button
              onClick={handleLogout}
              variant="outline"
              className="border-red-900 text-red-400 hover:bg-red-950"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-4 mb-6">
          <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-400">Portfolio Value</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <DollarSign className="w-6 h-6 text-blue-400" />
                <span className="text-2xl font-bold text-white">
                  ₹{portfolioSummary.totalValue.toLocaleString("en-IN", { maximumFractionDigits: 2 })}
                </span>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-400">Day P&L</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                {portfolioSummary.dayPnL >= 0 ? (
                  <TrendingUp className="w-6 h-6 text-emerald-400" />
                ) : (
                  <TrendingDown className="w-6 h-6 text-red-400" />
                )}
                <span className={`text-2xl font-bold ${portfolioSummary.dayPnL >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                  ₹{Math.abs(portfolioSummary.dayPnL).toLocaleString("en-IN", { maximumFractionDigits: 2 })}
                </span>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-400">Available Margin</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <Activity className="w-6 h-6 text-purple-400" />
                <span className="text-2xl font-bold text-white">
                  ₹{margins?.available_margin?.toLocaleString("en-IN", { maximumFractionDigits: 2 }) || "0"}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="positions" className="space-y-4">
          <TabsList className="bg-slate-900 border border-slate-800">
            <TabsTrigger value="positions" className="data-[state=active]:bg-slate-800">
              Positions ({positions.length})
            </TabsTrigger>
            <TabsTrigger value="orders" className="data-[state=active]:bg-slate-800">
              Orders ({orders.length})
            </TabsTrigger>
            <TabsTrigger value="holdings" className="data-[state=active]:bg-slate-800">
              Holdings ({holdings.length})
            </TabsTrigger>
            <TabsTrigger value="place-order" className="data-[state=active]:bg-slate-800">
              <PlusCircle className="w-4 h-4 mr-1" />
              Place Order
            </TabsTrigger>
          </TabsList>

          <TabsContent value="positions">
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white">Open Positions</CardTitle>
                <CardDescription className="text-slate-400">
                  Your current trading positions
                </CardDescription>
              </CardHeader>
              <CardContent>
                {positions.length === 0 ? (
                  <p className="text-slate-400 text-center py-8">No open positions</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow className="border-slate-800">
                        <TableHead className="text-slate-400">Symbol</TableHead>
                        <TableHead className="text-slate-400">Exchange</TableHead>
                        <TableHead className="text-slate-400">Qty</TableHead>
                        <TableHead className="text-slate-400">Buy Avg</TableHead>
                        <TableHead className="text-slate-400">Sell Avg</TableHead>
                        <TableHead className="text-slate-400">P&L</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {positions.map((position, index) => (
                        <TableRow key={index} className="border-slate-800">
                          <TableCell className="text-white font-medium">{position.trading_symbol}</TableCell>
                          <TableCell className="text-slate-400">{position.exchange}</TableCell>
                          <TableCell className="text-slate-400">{position.quantity}</TableCell>
                          <TableCell className="text-slate-400">₹{position.buy_avg}</TableCell>
                          <TableCell className="text-slate-400">₹{position.sell_avg}</TableCell>
                          <TableCell className={position.pnl >= 0 ? "text-emerald-400" : "text-red-400"}>
                            ₹{position.pnl.toFixed(2)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="orders">
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white">Order Book</CardTitle>
                <CardDescription className="text-slate-400">
                  Your recent and pending orders
                </CardDescription>
              </CardHeader>
              <CardContent>
                {orders.length === 0 ? (
                  <p className="text-slate-400 text-center py-8">No orders found</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow className="border-slate-800">
                        <TableHead className="text-slate-400">Symbol</TableHead>
                        <TableHead className="text-slate-400">Type</TableHead>
                        <TableHead className="text-slate-400">Qty</TableHead>
                        <TableHead className="text-slate-400">Price</TableHead>
                        <TableHead className="text-slate-400">Status</TableHead>
                        <TableHead className="text-slate-400">Action</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {orders.map((order) => (
                        <TableRow key={order.order_id} className="border-slate-800">
                          <TableCell className="text-white font-medium">{order.trading_symbol}</TableCell>
                          <TableCell>
                            <Badge variant={order.transaction_type === "B" ? "default" : "destructive"}>
                              {order.transaction_type === "B" ? "BUY" : "SELL"}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-slate-400">{order.quantity}</TableCell>
                          <TableCell className="text-slate-400">₹{order.price}</TableCell>
                          <TableCell>
                            <Badge variant={order.status === "COMPLETE" ? "default" : "secondary"}>
                              {order.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {order.status === "PENDING" && (
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => handleCancelOrder(order.order_id)}
                              >
                                Cancel
                              </Button>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="holdings">
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white">Holdings</CardTitle>
                <CardDescription className="text-slate-400">
                  Your long-term investments
                </CardDescription>
              </CardHeader>
              <CardContent>
                {holdings.length === 0 ? (
                  <p className="text-slate-400 text-center py-8">No holdings found</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow className="border-slate-800">
                        <TableHead className="text-slate-400">Symbol</TableHead>
                        <TableHead className="text-slate-400">Quantity</TableHead>
                        <TableHead className="text-slate-400">Avg Price</TableHead>
                        <TableHead className="text-slate-400">Current Price</TableHead>
                        <TableHead className="text-slate-400">P&L</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {holdings.map((holding, index) => (
                        <TableRow key={index} className="border-slate-800">
                          <TableCell className="text-white font-medium">{holding.trading_symbol}</TableCell>
                          <TableCell className="text-slate-400">{holding.quantity}</TableCell>
                          <TableCell className="text-slate-400">₹{holding.average_price}</TableCell>
                          <TableCell className="text-slate-400">₹{holding.current_price}</TableCell>
                          <TableCell className={holding.pnl >= 0 ? "text-emerald-400" : "text-red-400"}>
                            ₹{holding.pnl.toFixed(2)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="place-order">
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white">Place New Order</CardTitle>
                <CardDescription className="text-slate-400">
                  Enter order details to execute a trade
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-slate-300">Trading Symbol</Label>
                    <Input
                      value={orderForm.trading_symbol}
                      onChange={(e) => setOrderForm({ ...orderForm, trading_symbol: e.target.value })}
                      placeholder="e.g., RELIANCE"
                      className="bg-slate-800 border-slate-700 text-white"
                    />
                  </div>

                  <div>
                    <Label className="text-slate-300">Exchange</Label>
                    <Select
                      value={orderForm.exchange_segment}
                      onValueChange={(value) => setOrderForm({ ...orderForm, exchange_segment: value })}
                    >
                      <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-800 border-slate-700">
                        <SelectItem value="nse_cm">NSE Cash</SelectItem>
                        <SelectItem value="bse_cm">BSE Cash</SelectItem>
                        <SelectItem value="nse_fo">NSE F&O</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-slate-300">Transaction Type</Label>
                    <Select
                      value={orderForm.transaction_type}
                      onValueChange={(value) => setOrderForm({ ...orderForm, transaction_type: value })}
                    >
                      <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-800 border-slate-700">
                        <SelectItem value="B">Buy</SelectItem>
                        <SelectItem value="S">Sell</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-slate-300">Product Type</Label>
                    <Select
                      value={orderForm.product}
                      onValueChange={(value) => setOrderForm({ ...orderForm, product: value })}
                    >
                      <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-800 border-slate-700">
                        <SelectItem value="CNC">CNC (Delivery)</SelectItem>
                        <SelectItem value="MIS">MIS (Intraday)</SelectItem>
                        <SelectItem value="NRML">NRML (Normal)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-slate-300">Order Type</Label>
                    <Select
                      value={orderForm.order_type}
                      onValueChange={(value) => setOrderForm({ ...orderForm, order_type: value })}
                    >
                      <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-800 border-slate-700">
                        <SelectItem value="L">Limit</SelectItem>
                        <SelectItem value="MKT">Market</SelectItem>
                        <SelectItem value="SL">Stop Loss</SelectItem>
                        <SelectItem value="SL-M">Stop Loss Market</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-slate-300">Quantity</Label>
                    <Input
                      type="number"
                      value={orderForm.quantity}
                      onChange={(e) => setOrderForm({ ...orderForm, quantity: e.target.value })}
                      placeholder="Enter quantity"
                      className="bg-slate-800 border-slate-700 text-white"
                    />
                  </div>

                  <div>
                    <Label className="text-slate-300">Price</Label>
                    <Input
                      type="number"
                      step="0.05"
                      value={orderForm.price}
                      onChange={(e) => setOrderForm({ ...orderForm, price: e.target.value })}
                      placeholder="Enter price"
                      className="bg-slate-800 border-slate-700 text-white"
                      disabled={orderForm.order_type === "MKT" || orderForm.order_type === "SL-M"}
                    />
                  </div>

                  <div>
                    <Label className="text-slate-300">Validity</Label>
                    <Select
                      value={orderForm.validity}
                      onValueChange={(value) => setOrderForm({ ...orderForm, validity: value })}
                    >
                      <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-800 border-slate-700">
                        <SelectItem value="DAY">Day</SelectItem>
                        <SelectItem value="IOC">Immediate or Cancel</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Button
                  onClick={handlePlaceOrder}
                  disabled={loading || !orderForm.trading_symbol || !orderForm.quantity || (!orderForm.price && orderForm.order_type === "L")}
                  className="w-full bg-emerald-600 hover:bg-emerald-700"
                >
                  {loading ? "Placing Order..." : "Place Order"}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
