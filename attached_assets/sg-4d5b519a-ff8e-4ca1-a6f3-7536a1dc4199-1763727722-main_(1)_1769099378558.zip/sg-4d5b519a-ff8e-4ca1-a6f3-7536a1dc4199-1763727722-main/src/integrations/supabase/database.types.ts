 
export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      app_settings: {
        Row: {
          created_at: string | null
          id: string
          key: string
          updated_at: string | null
          user_id: string | null
          value: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          key: string
          updated_at?: string | null
          user_id?: string | null
          value: string
        }
        Update: {
          created_at?: string | null
          id?: string
          key?: string
          updated_at?: string | null
          user_id?: string | null
          value?: string
        }
        Relationships: [
          {
            foreignKeyName: "app_settings_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      indicator_webhook_test_log: {
        Row: {
          error_message: string | null
          id: string
          response_message: string | null
          status: string
          status_code: number | null
          test_payload: Json | null
          tested_at: string | null
          user_id: string
          webhook_id: string
        }
        Insert: {
          error_message?: string | null
          id?: string
          response_message?: string | null
          status: string
          status_code?: number | null
          test_payload?: Json | null
          tested_at?: string | null
          user_id: string
          webhook_id: string
        }
        Update: {
          error_message?: string | null
          id?: string
          response_message?: string | null
          status?: string
          status_code?: number | null
          test_payload?: Json | null
          tested_at?: string | null
          user_id?: string
          webhook_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "webhook_test_logs_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string | null
          email: string | null
          full_name: string | null
          id: string
          role: string | null
          updated_at: string | null
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string | null
          email?: string | null
          full_name?: string | null
          id: string
          role?: string | null
          updated_at?: string | null
        }
        Update: {
          avatar_url?: string | null
          created_at?: string | null
          email?: string | null
          full_name?: string | null
          id?: string
          role?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      webhook_logs: {
        Row: {
          created_at: string | null
          error_message: string | null
          id: string
          request_body: Json
          response_body: Json | null
          status_code: number
          user_id: string | null
          webhook_id: string
        }
        Insert: {
          created_at?: string | null
          error_message?: string | null
          id?: string
          request_body?: Json
          response_body?: Json | null
          status_code?: number
          user_id?: string | null
          webhook_id: string
        }
        Update: {
          created_at?: string | null
          error_message?: string | null
          id?: string
          request_body?: Json
          response_body?: Json | null
          status_code?: number
          user_id?: string | null
          webhook_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "webhook_logs_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      webhook_status_logs: {
        Row: {
          action_done: string | null
          alert: string | null
          alert_divergence: number | null
          created_at: string | null
          exchan: string | null
          first_price: number | null
          ht: number | null
          id: string
          indicator: string | null
          indices: string | null
          local_time: string | null
          lock_state: string | null
          mid_line: number | null
          mode: string | null
          mode_desc: string | null
          narration_by_alina_the_astra_jsonn: string | null
          price: number | null
          rsi: number | null
          rsi_divergence: number | null
          slow_line: number | null
          st: number | null
          time_as_per_hrnik: string | null
          webhook_id: string | null
        }
        Insert: {
          action_done?: string | null
          alert?: string | null
          alert_divergence?: number | null
          created_at?: string | null
          exchan?: string | null
          first_price?: number | null
          ht?: number | null
          id?: string
          indicator?: string | null
          indices?: string | null
          local_time?: string | null
          lock_state?: string | null
          mid_line?: number | null
          mode?: string | null
          mode_desc?: string | null
          narration_by_alina_the_astra_jsonn?: string | null
          price?: number | null
          rsi?: number | null
          rsi_divergence?: number | null
          slow_line?: number | null
          st?: number | null
          time_as_per_hrnik?: string | null
          webhook_id?: string | null
        }
        Update: {
          action_done?: string | null
          alert?: string | null
          alert_divergence?: number | null
          created_at?: string | null
          exchan?: string | null
          first_price?: number | null
          ht?: number | null
          id?: string
          indicator?: string | null
          indices?: string | null
          local_time?: string | null
          lock_state?: string | null
          mid_line?: number | null
          mode?: string | null
          mode_desc?: string | null
          narration_by_alina_the_astra_jsonn?: string | null
          price?: number | null
          rsi?: number | null
          rsi_divergence?: number | null
          slow_line?: number | null
          st?: number | null
          time_as_per_hrnik?: string | null
          webhook_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "webhook_status_logs_webhook_id_fkey"
            columns: ["webhook_id"]
            isOneToOne: false
            referencedRelation: "webhooks"
            referencedColumns: ["id"]
          },
        ]
      }
      webhook_sun_7_99_14_btc: {
        Row: {
          action_binary: number | null
          alert: string | null
          alert_system: string | null
          created_at: string | null
          exchange: string | null
          first_line: number | null
          ht: number | null
          id: string
          indicator: string | null
          indices: string | null
          local_time: string | null
          lock_state: string | null
          mid_line: number | null
          mode: string | null
          mode_desc: string | null
          price: number | null
          rsi: number | null
          rsi_scaled: number | null
          slow_line: number | null
          st: number | null
          time_unix: number | null
          user_id: string | null
        }
        Insert: {
          action_binary?: number | null
          alert?: string | null
          alert_system?: string | null
          created_at?: string | null
          exchange?: string | null
          first_line?: number | null
          ht?: number | null
          id?: string
          indicator?: string | null
          indices?: string | null
          local_time?: string | null
          lock_state?: string | null
          mid_line?: number | null
          mode?: string | null
          mode_desc?: string | null
          price?: number | null
          rsi?: number | null
          rsi_scaled?: number | null
          slow_line?: number | null
          st?: number | null
          time_unix?: number | null
          user_id?: string | null
        }
        Update: {
          action_binary?: number | null
          alert?: string | null
          alert_system?: string | null
          created_at?: string | null
          exchange?: string | null
          first_line?: number | null
          ht?: number | null
          id?: string
          indicator?: string | null
          indices?: string | null
          local_time?: string | null
          lock_state?: string | null
          mid_line?: number | null
          mode?: string | null
          mode_desc?: string | null
          price?: number | null
          rsi?: number | null
          rsi_scaled?: number | null
          slow_line?: number | null
          st?: number | null
          time_unix?: number | null
          user_id?: string | null
        }
        Relationships: []
      }
      webhooks: {
        Row: {
          created_at: string | null
          id: string
          is_active: boolean | null
          name: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          is_active?: boolean | null
          name: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          is_active?: boolean | null
          name?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "webhooks_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      execute_sql: { Args: { sql: string }; Returns: undefined }
      get_table_columns: {
        Args: { table_name: string }
        Returns: {
          column_name: string
          data_type: string
        }[]
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
