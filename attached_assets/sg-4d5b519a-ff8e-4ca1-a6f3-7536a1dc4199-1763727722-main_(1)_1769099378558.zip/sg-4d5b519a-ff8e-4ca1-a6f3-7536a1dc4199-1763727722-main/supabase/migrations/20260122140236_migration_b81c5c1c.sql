CREATE TABLE webhook_status_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  time_as_per_hrnik TIMESTAMP WITH TIME ZONE,
  exchan TEXT,
  indices TEXT,
  indicator TEXT,
  alert TEXT,
  price DECIMAL,
  local_time TIMESTAMP WITH TIME ZONE,
  mode TEXT,
  mode_desc TEXT,
  first_price DECIMAL,
  mid_line DECIMAL,
  slow_line DECIMAL,
  st DECIMAL,
  ht DECIMAL,
  rsi DECIMAL,
  rsi_divergence DECIMAL,
  alert_divergence DECIMAL,
  action_done TEXT,
  lock_state TEXT,
  narration_by_alina_the_astra_jsonn TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE webhook_status_logs ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can view their own webhook status logs" ON webhook_status_logs FOR SELECT USING (true);
CREATE POLICY "Users can insert webhook status logs" ON webhook_status_logs FOR INSERT WITH CHECK (true);
CREATE POLICY "Users can update webhook status logs" ON webhook_status_logs FOR UPDATE USING (true);
CREATE POLICY "Users can delete webhook status logs" ON webhook_status_logs FOR DELETE USING (true);