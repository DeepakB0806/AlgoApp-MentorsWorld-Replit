-- Update webadmin@mentorsworld.org to super_admin role
UPDATE profiles 
SET role = 'super_admin', 
    full_name = 'Super Admin',
    updated_at = NOW()
WHERE email = 'webadmin@mentorsworld.org';

-- Create a protection policy to prevent deletion of super_admin accounts
DROP POLICY IF EXISTS "Protect super admin accounts" ON profiles;
CREATE POLICY "Protect super admin accounts" ON profiles
FOR DELETE
USING (role != 'super_admin');

-- Create a protection policy to prevent role changes on super_admin accounts
DROP POLICY IF EXISTS "Protect super admin role changes" ON profiles;
CREATE POLICY "Protect super admin role changes" ON profiles
FOR UPDATE
USING (
  CASE 
    WHEN role = 'super_admin' THEN auth.uid() = id
    ELSE true
  END
);

-- Add a comment to document this protected account
COMMENT ON TABLE profiles IS 'Profiles table. Account webadmin@mentorsworld.org is a protected SuperAdmin account that cannot be deleted or downgraded.';