-- Update RLS policies on webhook_logs to allow inserts without user_id
DROP POLICY IF EXISTS "Users can insert their own webhook logs" ON webhook_logs;
DROP POLICY IF EXISTS "Users can view their own webhook logs" ON webhook_logs;

-- Allow anyone to insert webhook logs (for unauthenticated webhook calls)
CREATE POLICY "Allow webhook inserts" ON webhook_logs 
  FOR INSERT 
  WITH CHECK (true);

-- Allow users to view their own logs or logs without user_id
CREATE POLICY "Users can view webhook logs" ON webhook_logs 
  FOR SELECT 
  USING (auth.uid() = user_id OR user_id IS NULL);