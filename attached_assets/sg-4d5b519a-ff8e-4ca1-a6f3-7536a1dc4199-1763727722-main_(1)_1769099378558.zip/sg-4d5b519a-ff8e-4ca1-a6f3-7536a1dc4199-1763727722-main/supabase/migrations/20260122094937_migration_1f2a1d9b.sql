-- Drop ALL policies from both tables
DO $$ 
DECLARE
    r RECORD;
BEGIN
    -- Drop all policies from profiles table
    FOR r IN (SELECT policyname FROM pg_policies WHERE tablename = 'profiles') LOOP
        EXECUTE 'DROP POLICY IF EXISTS ' || quote_ident(r.policyname) || ' ON profiles';
    END LOOP;
    
    -- Drop all policies from webhook_sun_7_99_14_btc table
    FOR r IN (SELECT policyname FROM pg_policies WHERE tablename = 'webhook_sun_7_99_14_btc') LOOP
        EXECUTE 'DROP POLICY IF EXISTS ' || quote_ident(r.policyname) || ' ON webhook_sun_7_99_14_btc';
    END LOOP;
END $$;