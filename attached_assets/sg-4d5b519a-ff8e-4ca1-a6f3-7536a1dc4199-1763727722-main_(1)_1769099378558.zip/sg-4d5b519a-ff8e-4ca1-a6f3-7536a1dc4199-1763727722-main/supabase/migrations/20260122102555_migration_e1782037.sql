-- Drop the table if it exists (to start fresh)
DROP TABLE IF EXISTS public.webhook_test_logs CASCADE;

-- Create webhook_test_logs table to store test history
-- Store webhook_id as TEXT since webhooks are stored in app_settings, not a separate table
CREATE TABLE public.webhook_test_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  webhook_id TEXT NOT NULL,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  status TEXT NOT NULL,
  http_status INTEGER,
  response_message TEXT,
  test_payload JSONB,
  error_message TEXT,
  tested_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.webhook_test_logs ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view their own test logs" 
  ON public.webhook_test_logs FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own test logs" 
  ON public.webhook_test_logs FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own test logs" 
  ON public.webhook_test_logs FOR DELETE 
  USING (auth.uid() = user_id);

-- Create indexes for faster queries
CREATE INDEX idx_webhook_test_logs_webhook_id ON public.webhook_test_logs(webhook_id);
CREATE INDEX idx_webhook_test_logs_user_id ON public.webhook_test_logs(user_id);
CREATE INDEX idx_webhook_test_logs_tested_at ON public.webhook_test_logs(tested_at DESC);