-- Create the missing webhooks table
CREATE TABLE IF NOT EXISTS webhooks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE webhooks ENABLE ROW LEVEL SECURITY;

-- Create policies (idempotent checks not needed as we use IF NOT EXISTS for table, but policies might error if exist, so we drop first just in case or assume fresh)
DROP POLICY IF EXISTS "Users can view their own webhooks" ON webhooks;
DROP POLICY IF EXISTS "Users can insert their own webhooks" ON webhooks;
DROP POLICY IF EXISTS "Users can update their own webhooks" ON webhooks;
DROP POLICY IF EXISTS "Users can delete their own webhooks" ON webhooks;

CREATE POLICY "Users can view their own webhooks" ON webhooks FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their own webhooks" ON webhooks FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own webhooks" ON webhooks FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own webhooks" ON webhooks FOR DELETE USING (auth.uid() = user_id);