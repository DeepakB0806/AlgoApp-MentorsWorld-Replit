-- Rename webhook_test_logs to indicator_webhook_test_log
ALTER TABLE webhook_test_logs RENAME TO indicator_webhook_test_log;