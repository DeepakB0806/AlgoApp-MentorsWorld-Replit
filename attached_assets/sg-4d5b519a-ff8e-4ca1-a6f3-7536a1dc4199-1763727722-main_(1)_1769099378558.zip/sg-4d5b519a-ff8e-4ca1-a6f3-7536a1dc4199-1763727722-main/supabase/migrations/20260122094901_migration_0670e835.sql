-- First, drop ALL existing policies on profiles table
DROP POLICY IF EXISTS "Users can view their own profile" ON profiles;
DROP POLICY IF EXISTS "Users can insert their own profile" ON profiles;
DROP POLICY IF EXISTS "Users can update their own profile" ON profiles;
DROP POLICY IF EXISTS "Super admins can view all profiles" ON profiles;

-- Drop all existing policies on webhook table
DROP POLICY IF EXISTS "Super admins can view all webhook logs" ON webhook_sun_7_99_14_btc;
DROP POLICY IF EXISTS "Users can view their own webhook logs" ON webhook_sun_7_99_14_btc;
DROP POLICY IF EXISTS "Anyone can insert webhook logs" ON webhook_sun_7_99_14_btc;
DROP POLICY IF EXISTS "Users can insert their own webhook logs" ON webhook_sun_7_99_14_btc;
DROP POLICY IF EXISTS "Users can update their own webhook logs" ON webhook_sun_7_99_14_btc;
DROP POLICY IF EXISTS "Users can delete their own webhook logs" ON webhook_sun_7_99_14_btc;