-- Add webhook_id column to webhook_status_logs table with correct foreign key
ALTER TABLE webhook_status_logs 
ADD COLUMN webhook_id UUID REFERENCES webhooks(id) ON DELETE CASCADE;

-- Create an index for better query performance
CREATE INDEX idx_webhook_status_logs_webhook_id ON webhook_status_logs(webhook_id);