-- Make time_unix nullable since it might not always be provided
ALTER TABLE webhook_sun_7_99_14_btc 
ALTER COLUMN time_unix DROP NOT NULL;

-- Add user_id column to track which user's webhook received the data
ALTER TABLE webhook_sun_7_99_14_btc 
ADD COLUMN IF NOT EXISTS user_id uuid REFERENCES auth.users(id);

-- Create index on user_id for faster queries
CREATE INDEX IF NOT EXISTS idx_webhook_sun_user_id 
ON webhook_sun_7_99_14_btc(user_id);