-- Create webhook_logs table for live data tracking
CREATE TABLE IF NOT EXISTS public.webhook_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  webhook_id TEXT NOT NULL,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  request_body JSONB NOT NULL DEFAULT '{}'::jsonb,
  response_body JSONB,
  status_code INTEGER NOT NULL DEFAULT 200,
  error_message TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.webhook_logs ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view their own webhook logs" ON public.webhook_logs FOR SELECT USING (auth.uid() = user_id OR user_id IS NULL);
CREATE POLICY "Anyone can insert webhook logs" ON public.webhook_logs FOR INSERT WITH CHECK (true);
CREATE POLICY "Users can update their own webhook logs" ON public.webhook_logs FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own webhook logs" ON public.webhook_logs FOR DELETE USING (auth.uid() = user_id);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_webhook_logs_webhook_id ON public.webhook_logs(webhook_id);
CREATE INDEX IF NOT EXISTS idx_webhook_logs_created_at ON public.webhook_logs(created_at DESC);