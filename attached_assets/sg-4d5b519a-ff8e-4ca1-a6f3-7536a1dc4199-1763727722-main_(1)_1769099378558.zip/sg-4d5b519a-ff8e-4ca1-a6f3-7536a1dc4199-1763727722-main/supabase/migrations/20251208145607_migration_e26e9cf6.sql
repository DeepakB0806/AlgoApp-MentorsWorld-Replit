-- Create table for webhook: SUN 7.99.14 BTC
CREATE TABLE webhook_sun_7_99_14_btc (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  time_unix BIGINT NOT NULL,
  exchange TEXT,
  indices TEXT,
  indicator TEXT,
  alert TEXT,
  price DECIMAL(20, 8),
  local_time TIMESTAMP WITH TIME ZONE,
  mode TEXT,
  mode_desc TEXT,
  first_line DECIMAL(20, 8),
  mid_line DECIMAL(20, 8),
  slow_line DECIMAL(20, 8),
  st DECIMAL(20, 8),
  ht DECIMAL(20, 8),
  rsi DECIMAL(10, 4),
  rsi_scaled DECIMAL(10, 4),
  alert_system TEXT,
  action_binary INTEGER,
  lock_state TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE webhook_sun_7_99_14_btc ENABLE ROW LEVEL SECURITY;

-- Create policies for webhook logging
-- Super admins can view all webhook logs
CREATE POLICY "Super admins can view all webhook logs" 
  ON webhook_sun_7_99_14_btc 
  FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'super_admin'
    )
  );

-- Allow API to insert webhook data (public endpoint)
CREATE POLICY "Allow webhook insertions" 
  ON webhook_sun_7_99_14_btc 
  FOR INSERT 
  WITH CHECK (true);

-- Users can view their own webhook logs (if we add user_id later)
CREATE POLICY "Users can view webhook logs" 
  ON webhook_sun_7_99_14_btc 
  FOR SELECT 
  USING (true);

-- Create index on time_unix for faster queries
CREATE INDEX idx_webhook_sun_time_unix ON webhook_sun_7_99_14_btc(time_unix DESC);

-- Create index on indicator for filtering
CREATE INDEX idx_webhook_sun_indicator ON webhook_sun_7_99_14_btc(indicator);

-- Create index on created_at for time-based queries
CREATE INDEX idx_webhook_sun_created_at ON webhook_sun_7_99_14_btc(created_at DESC);