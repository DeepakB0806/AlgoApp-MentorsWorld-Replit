-- Create simple, non-recursive RLS policies

-- PROFILES TABLE POLICIES
-- Users can view their own profile
CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  USING (auth.uid() = id);

-- Users can update their own profile
CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  USING (auth.uid() = id);

-- WEBHOOK TABLE POLICIES (No profile checks - breaking the circular reference)
-- Anyone authenticated can view webhook logs
CREATE POLICY "Authenticated users can view webhook logs"
  ON webhook_sun_7_99_14_btc FOR SELECT
  USING (auth.uid() IS NOT NULL);

-- Anyone authenticated can insert webhook logs
CREATE POLICY "Authenticated users can insert webhook logs"
  ON webhook_sun_7_99_14_btc FOR INSERT
  WITH CHECK (auth.uid() IS NOT NULL);

-- Anyone authenticated can update webhook logs
CREATE POLICY "Authenticated users can update webhook logs"
  ON webhook_sun_7_99_14_btc FOR UPDATE
  USING (auth.uid() IS NOT NULL);

-- Anyone authenticated can delete webhook logs
CREATE POLICY "Authenticated users can delete webhook logs"
  ON webhook_sun_7_99_14_btc FOR DELETE
  USING (auth.uid() IS NOT NULL);