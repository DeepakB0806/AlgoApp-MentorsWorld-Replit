-- Rename http_status to status_code to match the code
ALTER TABLE public.webhook_test_logs 
RENAME COLUMN http_status TO status_code;