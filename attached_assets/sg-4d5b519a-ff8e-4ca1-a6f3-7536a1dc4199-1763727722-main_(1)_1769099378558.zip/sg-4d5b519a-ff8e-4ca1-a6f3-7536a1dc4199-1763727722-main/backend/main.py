from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import os
from dotenv import load_dotenv
import pyotp
import json
from datetime import datetime, timedelta

from neo_api_client import NeoAPI

load_dotenv()

app = FastAPI(title="Algo Trading Backend", version="1.0.0")

# CORS Configuration
ALLOWED_ORIGINS = os.getenv("ALLOWED_ORIGINS", "http://localhost:3000").split(",")

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global client storage (In production, use Redis or database)
active_sessions: Dict[str, NeoAPI] = {}


# Pydantic Models
class LoginRequest(BaseModel):
    consumer_key: str
    consumer_secret: str
    mobile_number: str
    password: str
    mpin: str
    totp_secret: Optional[str] = None


class OrderRequest(BaseModel):
    exchange_segment: str  # nse_cm, bse_cm, nse_fo, etc.
    product: str  # NRML, CNC, MIS
    price: str
    order_type: str  # L, MKT, SL, SL-M
    quantity: str
    validity: str  # DAY, IOC
    trading_symbol: str
    transaction_type: str  # B, S
    amo: str = "NO"
    disclosed_quantity: str = "0"
    market_protection: str = "0"
    pf: str = "N"
    trigger_price: str = "0"
    tag: Optional[str] = None


class ModifyOrderRequest(BaseModel):
    order_id: str
    price: Optional[str] = None
    quantity: Optional[str] = None
    trigger_price: Optional[str] = None
    validity: Optional[str] = None
    order_type: Optional[str] = None


class QuoteRequest(BaseModel):
    instrument_tokens: List[str]
    quote_type: str = "market_depth"  # market_depth, ohlc, ltp


# Helper Functions
def generate_otp(totp_secret: str) -> str:
    """Generate OTP from TOTP secret"""
    totp = pyotp.TOTP(totp_secret)
    return totp.now()


def create_session(client: NeoAPI, customer_id: str) -> str:
    """Store active session and return session ID"""
    session_id = f"session_{customer_id}_{datetime.now().timestamp()}"
    active_sessions[session_id] = client
    return session_id


def get_session(session_id: str) -> Optional[NeoAPI]:
    """Retrieve active session"""
    return active_sessions.get(session_id)


# API Endpoints
@app.get("/")
async def root():
    return {
        "message": "Algo Trading Backend API",
        "version": "1.0.0",
        "status": "running"
    }


@app.post("/api/auth/login")
async def login(request: LoginRequest):
    """Authenticate with Kotak Neo and create session"""
    try:
        # Initialize Neo API client
        client = NeoAPI(
            consumer_key=request.consumer_key,
            consumer_secret=request.consumer_secret,
            environment='prod'  # Use 'prod' for live trading
        )
        
        # Generate OTP if TOTP secret provided
        otp = None
        if request.totp_secret:
            otp = generate_otp(request.totp_secret)
        
        # Login
        login_response = client.login(
            mobilenumber=request.mobile_number,
            password=request.password
        )
        
        if not login_response:
            raise HTTPException(status_code=401, detail="Login failed")
        
        # Session token generation
        session_response = client.session_2fa(OTP=otp if otp else request.mpin)
        
        if not session_response:
            raise HTTPException(status_code=401, detail="2FA failed")
        
        # Create and store session
        session_id = create_session(client, request.mobile_number)
        
        return {
            "success": True,
            "session_id": session_id,
            "message": "Authentication successful",
            "data": session_response
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Authentication error: {str(e)}")


@app.post("/api/orders/place")
async def place_order(order: OrderRequest, session_id: str):
    """Place a new order"""
    client = get_session(session_id)
    if not client:
        raise HTTPException(status_code=401, detail="Invalid or expired session")
    
    try:
        response = client.place_order(
            exchange_segment=order.exchange_segment,
            product=order.product,
            price=order.price,
            order_type=order.order_type,
            quantity=order.quantity,
            validity=order.validity,
            trading_symbol=order.trading_symbol,
            transaction_type=order.transaction_type,
            amo=order.amo,
            disclosed_quantity=order.disclosed_quantity,
            market_protection=order.market_protection,
            pf=order.pf,
            trigger_price=order.trigger_price,
            tag=order.tag
        )
        
        return {
            "success": True,
            "data": response
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Order placement failed: {str(e)}")


@app.post("/api/orders/modify")
async def modify_order(order: ModifyOrderRequest, session_id: str):
    """Modify an existing order"""
    client = get_session(session_id)
    if not client:
        raise HTTPException(status_code=401, detail="Invalid or expired session")
    
    try:
        response = client.modify_order(
            order_id=order.order_id,
            price=order.price,
            quantity=order.quantity,
            trigger_price=order.trigger_price,
            validity=order.validity,
            order_type=order.order_type
        )
        
        return {
            "success": True,
            "data": response
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Order modification failed: {str(e)}")


@app.delete("/api/orders/cancel/{order_id}")
async def cancel_order(order_id: str, session_id: str):
    """Cancel an order"""
    client = get_session(session_id)
    if not client:
        raise HTTPException(status_code=401, detail="Invalid or expired session")
    
    try:
        response = client.cancel_order(order_id=order_id)
        
        return {
            "success": True,
            "data": response
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Order cancellation failed: {str(e)}")


@app.get("/api/orders")
async def get_orders(session_id: str):
    """Get order book"""
    client = get_session(session_id)
    if not client:
        raise HTTPException(status_code=401, detail="Invalid or expired session")
    
    try:
        response = client.order_report()
        
        return {
            "success": True,
            "data": response
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch orders: {str(e)}")


@app.get("/api/positions")
async def get_positions(session_id: str):
    """Get positions"""
    client = get_session(session_id)
    if not client:
        raise HTTPException(status_code=401, detail="Invalid or expired session")
    
    try:
        response = client.positions()
        
        return {
            "success": True,
            "data": response
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch positions: {str(e)}")


@app.get("/api/holdings")
async def get_holdings(session_id: str):
    """Get holdings"""
    client = get_session(session_id)
    if not client:
        raise HTTPException(status_code=401, detail="Invalid or expired session")
    
    try:
        response = client.holdings()
        
        return {
            "success": True,
            "data": response
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch holdings: {str(e)}")


@app.post("/api/quotes")
async def get_quotes(request: QuoteRequest, session_id: str):
    """Get market quotes"""
    client = get_session(session_id)
    if not client:
        raise HTTPException(status_code=401, detail="Invalid or expired session")
    
    try:
        response = client.quotes(
            instrument_tokens=request.instrument_tokens,
            quote_type=request.quote_type
        )
        
        return {
            "success": True,
            "data": response
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch quotes: {str(e)}")


@app.get("/api/margins")
async def get_margins(session_id: str):
    """Get margin details"""
    client = get_session(session_id)
    if not client:
        raise HTTPException(status_code=401, detail="Invalid or expired session")
    
    try:
        response = client.limits()
        
        return {
            "success": True,
            "data": response
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch margins: {str(e)}")


@app.get("/api/scrips/search")
async def search_scrips(query: str, session_id: str, exchange: str = "NSE"):
    """Search for trading symbols"""
    client = get_session(session_id)
    if not client:
        raise HTTPException(status_code=401, detail="Invalid or expired session")
    
    try:
        response = client.search_scrip(
            exchange_segment=f"{exchange.lower()}_cm",
            symbol=query
        )
        
        return {
            "success": True,
            "data": response
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Search failed: {str(e)}")


@app.delete("/api/auth/logout")
async def logout(session_id: str):
    """Logout and clear session"""
    if session_id in active_sessions:
        try:
            client = active_sessions[session_id]
            client.logout()
            del active_sessions[session_id]
            
            return {
                "success": True,
                "message": "Logged out successfully"
            }
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Logout failed: {str(e)}")
    
    raise HTTPException(status_code=404, detail="Session not found")


# WebSocket for real-time updates
@app.websocket("/ws/market-data/{session_id}")
async def market_data_websocket(websocket: WebSocket, session_id: str):
    """WebSocket connection for real-time market data"""
    await websocket.accept()
    
    client = get_session(session_id)
    if not client:
        await websocket.send_json({"error": "Invalid session"})
        await websocket.close()
        return
    
    try:
        while True:
            # Receive subscription requests
            data = await websocket.receive_text()
            message = json.loads(data)
            
            if message.get("type") == "subscribe":
                # Handle subscription logic here
                # This is a placeholder - actual implementation depends on Kotak Neo's websocket API
                await websocket.send_json({
                    "type": "subscribed",
                    "instruments": message.get("instruments", [])
                })
            
    except WebSocketDisconnect:
        print(f"WebSocket disconnected for session: {session_id}")
    except Exception as e:
        print(f"WebSocket error: {str(e)}")
        await websocket.close()


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host=os.getenv("HOST", "0.0.0.0"),
        port=int(os.getenv("PORT", 8000)),
        reload=True
    )