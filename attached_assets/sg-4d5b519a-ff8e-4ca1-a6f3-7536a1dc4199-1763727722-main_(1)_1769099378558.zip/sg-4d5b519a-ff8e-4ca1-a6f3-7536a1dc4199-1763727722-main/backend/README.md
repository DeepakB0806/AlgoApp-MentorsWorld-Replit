# Algo Trading Backend - Python FastAPI

Production-grade backend service for live trading with Kotak Neo API integration.

## Features

- ✅ Kotak Neo API Integration (Live Trading)
- ✅ Session Management & Authentication
- ✅ Order Placement, Modification & Cancellation
- ✅ Position & Holdings Management
- ✅ Real-time Market Data via WebSocket
- ✅ Margin & Limits Information
- ✅ Security with CORS & Environment Variables

## Setup Instructions

### 1. Install Python Dependencies

```bash
cd backend
pip install -r requirements.txt
```

### 2. Configure Environment Variables

Create a `.env` file in the `backend` directory:

```bash
cp .env.example .env
```

Edit `.env` with your Kotak Neo credentials:

```
KOTAK_CONSUMER_KEY=your_consumer_key_here
KOTAK_CONSUMER_SECRET=your_consumer_secret_here
KOTAK_MOBILE_NUMBER=your_mobile_number
KOTAK_PASSWORD=your_password
KOTAK_MPIN=your_mpin
KOTAK_TOTP_SECRET=your_totp_secret  # Optional for auto-login
```

### 3. Run the Backend Server

```bash
# Development mode with auto-reload
python main.py

# Or using uvicorn directly
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

The backend will be available at: `http://localhost:8000`

### 4. API Documentation

Once running, access interactive API docs at:
- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

## API Endpoints

### Authentication
- `POST /api/auth/login` - Login and create session
- `DELETE /api/auth/logout` - Logout and clear session

### Orders
- `POST /api/orders/place` - Place new order
- `POST /api/orders/modify` - Modify existing order
- `DELETE /api/orders/cancel/{order_id}` - Cancel order
- `GET /api/orders` - Get order book

### Portfolio
- `GET /api/positions` - Get open positions
- `GET /api/holdings` - Get holdings
- `GET /api/margins` - Get margin details

### Market Data
- `POST /api/quotes` - Get real-time quotes
- `GET /api/scrips/search` - Search trading symbols
- `WS /ws/market-data/{session_id}` - WebSocket for live data

## Security Notes

⚠️ **IMPORTANT for Live Trading:**

1. **Never commit `.env` file** - Contains sensitive credentials
2. **Use HTTPS in production** - Deploy behind reverse proxy (nginx/Caddy)
3. **Rotate API keys regularly** - Update credentials periodically
4. **Enable rate limiting** - Protect against abuse
5. **Monitor logs** - Track all trading activity
6. **Use strong SECRET_KEY** - For session management

## Deployment

### Option 1: Railway.app (Recommended)

```bash
# Install Railway CLI
npm install -g @railway/cli

# Login and deploy
railway login
railway init
railway up
```

### Option 2: Render.com

1. Create new Web Service
2. Connect GitHub repository
3. Build Command: `pip install -r backend/requirements.txt`
4. Start Command: `cd backend && python main.py`

### Option 3: DigitalOcean App Platform

1. Create new app
2. Select Python
3. Set root directory to `backend`
4. Add environment variables

### Option 4: AWS EC2

```bash
# SSH into EC2 instance
ssh -i your-key.pem ubuntu@your-ip

# Install dependencies
sudo apt update
sudo apt install python3-pip python3-venv

# Clone repository
git clone your-repo-url
cd your-repo/backend

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run with systemd (production)
sudo nano /etc/systemd/system/trading-backend.service
```

## Monitoring

### Health Check
```bash
curl http://localhost:8000/
```

### Session Management
Active sessions are stored in-memory. For production:
- Use Redis for session storage
- Implement session expiry
- Add session cleanup cron job

## Troubleshooting

### Common Issues

1. **Import Error: No module named 'neo_api_client'**
   ```bash
   pip install neo-api-client
   ```

2. **Authentication Failed**
   - Verify credentials in `.env`
   - Check if TOTP secret is correct
   - Ensure API keys are active in Kotak Neo dashboard

3. **CORS Error**
   - Add your frontend URL to `ALLOWED_ORIGINS` in `.env`

4. **Port Already in Use**
   ```bash
   # Kill process on port 8000
   lsof -ti:8000 | xargs kill -9
   ```

## Next Steps

1. Connect your Next.js frontend to this backend
2. Implement strategy execution logic
3. Add backtesting capabilities
4. Set up monitoring and alerts
5. Deploy to production

## Support

For Kotak Neo API documentation:
https://github.com/Kotak-Neo/kotak-neo-api