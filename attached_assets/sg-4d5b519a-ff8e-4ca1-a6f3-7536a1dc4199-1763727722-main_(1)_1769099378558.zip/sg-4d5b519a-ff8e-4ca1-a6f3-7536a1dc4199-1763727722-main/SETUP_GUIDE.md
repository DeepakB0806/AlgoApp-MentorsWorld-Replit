# Complete Setup Guide - Algo Trading Platform

## 🚀 Quick Start Guide

This guide will help you set up the complete algo trading platform with Python backend and Next.js frontend for **live trading** with Kotak Neo.

---

## 📋 Prerequisites

- **Node.js** v18+ installed
- **Python** 3.9+ installed
- **Kotak Neo Trading Account** with API access
- Basic knowledge of terminal/command line

---

## 🔧 Backend Setup (Python FastAPI)

### Step 1: Install Python Dependencies

```bash
cd backend
pip install -r requirements.txt
```

### Step 2: Configure Environment Variables

Create a `.env` file in the `backend` directory:

```bash
cp .env.example .env
```

Edit the `.env` file with your Kotak Neo credentials:

```env
KOTAK_CONSUMER_KEY=your_consumer_key_here
KOTAK_CONSUMER_SECRET=your_consumer_secret_here
KOTAK_MOBILE_NUMBER=your_mobile_number
KOTAK_PASSWORD=your_password
KOTAK_MPIN=your_mpin

# Optional: TOTP Secret for auto-login (recommended)
KOTAK_TOTP_SECRET=your_totp_secret

# Server Configuration
HOST=0.0.0.0
PORT=8000
ALLOWED_ORIGINS=http://localhost:3000,https://yourdomain.vercel.app

# Security
SECRET_KEY=change-this-to-a-random-secret-key
```

### Step 3: Run the Backend Server

```bash
# From backend directory
python main.py

# Or using uvicorn directly
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

The backend will be available at `http://localhost:8000`

### Step 4: Verify Backend is Running

Open your browser and navigate to:
- API Documentation: `http://localhost:8000/docs`
- Alternative Docs: `http://localhost:8000/redoc`

---

## 🎨 Frontend Setup (Next.js)

### Step 1: Install Node Dependencies

```bash
# From project root
npm install
```

### Step 2: Configure Environment Variables

Create a `.env.local` file in the project root:

```bash
cp .env.example .env.local
```

Edit the `.env.local` file:

```env
NEXT_PUBLIC_BACKEND_URL=http://localhost:8000
NEXT_PUBLIC_APP_NAME=Algo Trading Platform
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

### Step 3: Run the Frontend Development Server

```bash
npm run dev
```

The frontend will be available at `http://localhost:3000`

---

## 🔐 Getting Kotak Neo API Credentials

### Step 1: Create Kotak Neo Account

1. Visit [Kotak Securities](https://www.kotaksecurities.com/)
2. Open a trading and demat account
3. Complete KYC verification

### Step 2: Enable API Access

1. Login to your Kotak Neo account
2. Navigate to **Settings** → **API**
3. Click on **Create App** or **Generate API Keys**
4. Note down your:
   - Consumer Key
   - Consumer Secret

### Step 3: Setup TOTP (Recommended for Auto-Login)

1. In Kotak Neo dashboard, enable **Two-Factor Authentication**
2. Use an authenticator app (Google Authenticator, Authy)
3. Save the **TOTP Secret Key** (base32 encoded string)
4. Add this secret to your `.env` file as `KOTAK_TOTP_SECRET`

---

## 📱 Using the Platform

### 1. Access Live Trading Dashboard

1. Navigate to `http://localhost:3000`
2. Click on **"Live Trading Dashboard"**
3. Enter your Kotak Neo credentials:
   - Consumer Key
   - Consumer Secret
   - Mobile Number
   - Password
   - MPIN
   - TOTP Secret (optional but recommended)
4. Click **"Login to Dashboard"**

### 2. Dashboard Features

Once logged in, you can:

- **View Portfolio Summary**
  - Total portfolio value
  - Day P&L
  - Available margin

- **Manage Positions**
  - View open positions
  - Real-time P&L tracking
  - Position details (quantity, avg price, etc.)

- **Place Orders**
  - Buy/Sell orders
  - Multiple order types (Limit, Market, Stop Loss)
  - Different product types (CNC, MIS, NRML)
  - Exchange selection (NSE, BSE, F&O)

- **Order Management**
  - View order book
  - Cancel pending orders
  - Modify existing orders

- **Holdings**
  - View long-term investments
  - Current value and P&L

---

## 🔧 Advanced Configuration

### Setting up CORS for Production

In `backend/.env`, add your production domain:

```env
ALLOWED_ORIGINS=http://localhost:3000,https://yourdomain.com,https://yourdomain.vercel.app
```

### Environment-Specific Backend URLs

For development:
```env
NEXT_PUBLIC_BACKEND_URL=http://localhost:8000
```

For production:
```env
NEXT_PUBLIC_BACKEND_URL=https://your-backend-api.com
```

---

## 🚀 Deployment

### Backend Deployment Options

#### Option 1: Railway.app (Recommended)

```bash
# Install Railway CLI
npm install -g @railway/cli

# Login and deploy
railway login
railway init
railway up
```

#### Option 2: Render.com

1. Connect your GitHub repository
2. Create new **Web Service**
3. Set build command: `pip install -r backend/requirements.txt`
4. Set start command: `cd backend && python main.py`
5. Add environment variables from `.env`

#### Option 3: DigitalOcean App Platform

1. Create new app
2. Select Python runtime
3. Set root directory to `backend`
4. Configure environment variables

### Frontend Deployment (Vercel)

```bash
# Deploy to Vercel
vercel

# Or use GitHub integration
# Push to GitHub → Vercel auto-deploys
```

Don't forget to set `NEXT_PUBLIC_BACKEND_URL` in Vercel environment variables to your deployed backend URL.

---

## 🔒 Security Best Practices

### For Live Trading:

1. **Never commit `.env` or `.env.local` files**
   - Already in `.gitignore` but double-check

2. **Use HTTPS in production**
   - Backend: Deploy behind nginx/Caddy with SSL
   - Frontend: Vercel provides HTTPS automatically

3. **Rotate API keys regularly**
   - Change Kotak Neo credentials every 3-6 months

4. **Enable rate limiting**
   - Implement on backend to prevent API abuse

5. **Monitor all trades**
   - Set up logging and alerts for suspicious activity

6. **Use strong SECRET_KEY**
   - Generate with: `python -c "import secrets; print(secrets.token_hex(32))"`

---

## 🐛 Troubleshooting

### Backend Issues

**Error: "No module named 'neo_api_client'"**
```bash
pip install neo-api-client
```

**Error: "Authentication failed"**
- Verify credentials in `.env`
- Check if TOTP secret is correct
- Ensure API keys are active

**Error: "Port already in use"**
```bash
# Kill process on port 8000
lsof -ti:8000 | xargs kill -9
```

### Frontend Issues

**Error: "Failed to fetch"**
- Ensure backend is running on `http://localhost:8000`
- Check `NEXT_PUBLIC_BACKEND_URL` in `.env.local`

**Error: "CORS policy blocked"**
- Add frontend URL to `ALLOWED_ORIGINS` in backend `.env`

### Trading Issues

**Orders not executing**
- Verify sufficient margin available
- Check market hours (9:15 AM - 3:30 PM IST for equity)
- Ensure correct exchange segment

**Session expired**
- Re-login from dashboard
- Consider implementing token refresh logic

---

## 📚 API Documentation

Full API documentation is available at:
- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

### Key Endpoints:

- `POST /api/auth/login` - Authenticate with Kotak Neo
- `POST /api/orders/place` - Place new order
- `GET /api/positions` - Get open positions
- `GET /api/orders` - Get order book
- `GET /api/holdings` - Get holdings
- `POST /api/quotes` - Get real-time quotes

---

## 🎯 Next Steps

1. **Test with Paper Trading**
   - Start with small quantities
   - Verify order execution flow

2. **Implement Risk Management**
   - Set stop-loss levels
   - Position sizing rules
   - Daily loss limits

3. **Add Strategy Automation**
   - Connect TradingView alerts
   - Build automated entry/exit logic
   - Implement backtesting

4. **Monitor Performance**
   - Track all trades
   - Analyze P&L
   - Review and optimize strategies

---

## 📞 Support

For issues or questions:
- Backend (Kotak Neo): [Kotak Neo API Documentation](https://github.com/Kotak-Neo/kotak-neo-api)
- Platform Issues: Check the troubleshooting section above

---

## ⚠️ Disclaimer

**This is a trading platform that executes real trades with real money. Use at your own risk.**

- Start with small positions
- Test thoroughly in paper trading mode first
- Never trade more than you can afford to lose
- Past performance doesn't guarantee future results
- Always have a risk management strategy

---

Happy Trading! 🚀
