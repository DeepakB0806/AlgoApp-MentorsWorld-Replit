Kotak Neo Python SDK delta
===========================

Repository: https://github.com/Kotak-Neo/kotak-neo-python (main)
From snapshot commit: ac650e2728b2c947e91778def66bd2f2bceaab93
To current commit: 6e1bfb5b460b49c1023f841c1e3a906c7a41ed53
SDK version: 3.0.7 -> 3.0.8
Files: 38 modified, 5 added, 0 deleted.

Contents: changes.patch is the unified text diff (including additions/deletions where text-based). current/ contains the latest full contents of all added and modified files, retaining repository-relative paths. manifest.json lists exact file status. Binary changes, if any, are represented by the current file copies rather than text patch entries.
The original archive and project source were left unchanged.
