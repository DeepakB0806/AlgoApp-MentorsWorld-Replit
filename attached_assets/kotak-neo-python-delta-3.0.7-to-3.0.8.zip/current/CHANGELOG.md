# Changelog

All notable changes to this project are documented in this file.

## [3.0.8] - 2026-10-05

### New: automatic Positions P&L
- **`positions()` now computes `netQty`, `averagePrice`, `positionPnl`, `mtmPnl`,
  and `pnlCalculationError` for every position**, added alongside the raw broker
  fields — no more silently-wrong `average = LTP` / `P&L = 0` for a carry-forward
  position with no fills today. Equity carry-forward sources its true cost basis
  from [Holdings](docs/functions/portfolio/holdings.md) (matched on
  `positions.tok == holdings.exchangeIdentifier`); F&O carry-forward (no
  Holdings entry) is valued at previous close. A failure to compute any of these
  (e.g. no matching Holdings entry, or LTP unavailable) is reported per-position
  via `pnlCalculationError` instead of a silently wrong number. Full calculation
  breakdown: [docs/functions/portfolio/positions.md](docs/functions/portfolio/positions.md#positions-calculations--computed-automatically).
- `positions()` now calls `portfolio/v2/positions` (previously `quick/user/positions`),
  which returns its own `ltp` per position — used directly for the P&L fields above
  with no extra call in the common case. `quotes()` is only used as a fallback batch
  for any position missing (or with an unparseable) `ltp`.
- **`holdings()`** is unchanged for a direct call — it always hits the network, live.
  Internally, `positions()` now reuses a same-day cache of the last successful
  `holdings()` fetch (whether triggered by `positions()` itself or by you calling
  `holdings()` directly) instead of always re-fetching it — persisted to disk
  (`~/.kotak_neo/holdings_cache`, overridable via `NEO_HOLDINGS_CACHE_DIR`), so the
  cache survives across separate runs of the same script on the same day, not just
  within one process.

### Fixes
- **Order feed / SFeed could silently stop reconnecting after a disconnect**
  if a caller's `on_disconnect`/`on_error` callback raised — the exception
  propagated out of the internal reconnect loop, killing the background
  receive task with no further log output and no retry, while the caller's
  `async for` loop over the feed just ended quietly (no error surfaced).
  These callbacks are now exception-safe, matching `on_message`/`on_raw`
  (already guarded the same way): a callback bug degrades gracefully
  instead of silently stopping the feed.
- **Order feed / SFeed reconnect could falsely report failure (and burn
  through `max_reconnect_attempts`) even when the reconnect actually
  succeeded**, if a caller's `on_connect` callback raised. `on_connect()` is
  called after the socket is already open and the receive task already
  started, so letting it raise meant the internal reconnect loop's
  `await self.connect()` call looked like a failed attempt and retried
  against a connection that didn't need it — eventually exhausting
  `max_reconnect_attempts` and giving up for good, against what was actually
  a live connection. `on_connect` is now exception-safe too.

### Enhancements
- `quotes()`, `expiries()`, `option_chain()`, `historical_data()` now surface any
  `Retry-After`/`X-RateLimit-*` response headers the backend Trade APIs send,
  under a `rateLimit` key on the returned dict — giving callers a concrete
  value to back off on after a `429`. Only added when the backend actually
  sends one of these headers; absent otherwise, so existing response shapes
  are unaffected.
- `orderfeed_disconnected`/`sfeed_disconnected` log events now include
  `close_code`/`close_reason` — the actual WebSocket close frame the server
  (or the connection itself) sent, giving a concrete answer to why a
  disconnect happened instead of just that one happened.

### Docs
- `historical_data.md`, `expiries.md`, `option_chain.md` now document that
  these endpoints are backend-rate-limited (matching `quotes()`'s existing 25
  requests/second note) and how to read the new `rateLimit` field.
- `positions.md`/`holdings.md` document the P&L calculation, the holdings
  cache behavior, and the on-disk cache location/override above.
- `trade_report.md` now notes that the backend always returns an empty `tok`
  on this endpoint (unlike `order_report()`), and documents the workaround
  (match `nOrdNo` against `order_report()`, or resolve via `search_scrip()`).

## [3.0.7] - 2026-09-15

### Fixes
- **Order feed / SFeed crash after running for hours** (`RecursionError: maximum
  recursion depth exceeded`) — both WebSocket clients' idle-timeout retry
  (`__anext__()`) and reconnect retry (`_handle_disconnect()`) used recursion
  instead of a loop, so a long-idle connection or a run of failed reconnect
  attempts would eventually blow the stack. Both are now implemented as loops,
  so the feed can run indefinitely through idle periods or extended outages
  without crashing.
- Fixed `totp_login()`/`totp_validate()`/`whatsmyip()` sending the **prod** API
  path even when `environment="uat"` — these previously hardcoded the prod
  endpoint path regardless of environment; they now resolve the correct
  UAT-specific path.

## [3.0.6] - 2026-09-05

> Covers everything since the last tagged release, `v3.0.1` (2026-08-17). Versions
> 3.0.2–3.0.5 were internal version bumps that were never tagged/released on their own.

### New Functions
- **`expiries()`, `option_chain()`, `historical_data()`** — new market-data endpoints
  (expiry dates, option/futures chains, historical candles), with full docs under
  `docs/functions/market_data/`.
- **`place_order(tag=...)`** — caller-defined marker for tracking an order, echoed back
  as `GuiOrdId` in `order_report()`/`trade_report()`.

### WebSocket
- **Market status / CAS support** on the SFeed — session open/close, pre-open, and Closing
  Auction Session (CAS) transition notifications, plus CAS reference (imbalance) data.
- New **Jupyter Notebook support**: install guide, a Jupyter compatibility CI workflow,
  and a smoke-test notebook.
- New **sync-integration guide** (`docs/guides/sync-integration.md`) for bridging the
  async SFeed/order-feed clients into synchronous, multi-process apps (Django/Flask
  behind gunicorn/uWSGI, Celery workers).

### Logging (significant overhaul)
- Structured JSON logging via `structlog`, with independently configurable console and
  rotating-file outputs (`NEO_LOG_LEVEL`, `NEO_LOG_FILE_ENABLED`/`PATH`/`LEVEL`).
- Large response bodies are size-capped in the log (with a preview) instead of bloating
  the log file; sensitive fields are auto-masked.
- Consolidated so each REST call now writes **one** log line instead of several — merged
  the separate "request start" and "success/error" events, and pinned `httpx`'s own
  internal logger to `WARNING` so it no longer duplicates every request in the log.
- `totp_login()`/`totp_validate()`'s function-result log now records only a status, not
  the full response (avoids repeating the auth token across two log lines).
- Our log handlers now attach to a dedicated `neo_api_client` logger instead of the root
  logger, and no longer propagate past it — so they can't collide with (and duplicate)
  whatever logging setup the host application itself uses.

### Dependencies
- Routine `ruff` version bumps via Dependabot (0.16.2 → 0.16.5).

## [3.0.1] - 2026-08-17

Last previously tagged release.
